"""
Writes docs/sample_rows.md containing the first 10 rows of each batch file
and one example each of a CDC INSERT and UPDATE event.

Usage:
    python code/make_sample_rows.py
"""

import csv
import json
import os
import sys

data = sys.argv[1] if len(sys.argv) > 1 else "data"
out = sys.argv[2] if len(sys.argv) > 2 else os.path.join("docs", "sample_rows.md")

lines = ["# Sample rows", "",
         "The first 10 rows of each file in the default dataset (seed 312). All values are fictional.", ""]
for name in ["customers.csv", "accounts.csv", "transactions.csv"]:
    with open(os.path.join(data, name), newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))[:11]
    lines += [f"## {name}", "", "| " + " | ".join(rows[0]) + " |", "|" + "---|" * len(rows[0])]
    lines += ["| " + " | ".join(r) + " |" for r in rows[1:]]
    lines.append("")

with open(os.path.join(data, "cdc_events.jsonl"), encoding="utf-8") as f:
    events = [json.loads(l) for l in f if l.strip()]
ins = next(e for e in events if e["operation"] == "INSERT")
upd = next(e for e in events if e["operation"] == "UPDATE")
lines += ["## cdc_events.jsonl", "",
          "Each event is stored on a single line in the file. The examples below are formatted for readability.", "",
          f"### INSERT example ({ins['event_id']})", "", "```json", json.dumps(ins, indent=2), "```", "",
          f"### UPDATE example ({upd['event_id']}): pending transaction settled", "",
          "```json", json.dumps(upd, indent=2), "```", ""]
with open(out, "w", encoding="utf-8", newline="\n") as f:
    f.write("\n".join(lines))
print("wrote", out)
