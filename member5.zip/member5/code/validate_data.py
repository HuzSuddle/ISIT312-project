"""
Data quality validation for the synthetic banking dataset.

Checks primary keys, referential integrity, required columns, formats, allowed values,
amounts, CDC semantics, row counts, reproducibility, chronology and data coverage.

Usage:
    python code/validate_data.py               # validate data/ and save docs/validation_results.txt
    python code/validate_data.py --fixtures    # also confirm the test fixtures in data/tests/ are rejected

Exit code 0 means all checks passed; 1 means at least one check failed.
"""

import argparse
import csv
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import date, datetime

HERE = os.path.dirname(os.path.abspath(__file__))

CUSTOMER_COLS = ["customer_id", "customer_type", "region_code", "registration_date", "status"]
ACCOUNT_COLS = ["account_id", "customer_id", "account_type", "opened_date", "currency", "status"]
TXN_COLS = ["transaction_id", "account_id", "event_ts", "txn_date", "amount", "currency",
            "transaction_type", "channel", "status"]
CDC_KEYS = {"event_id", "schema_version", "entity", "record_id", "operation", "event_time", "before", "after"}
CDC_OPTIONAL = {"source"}

ALLOWED = {
    "customer_type": {"RETAIL", "MSME"},
    "customer_status": {"ACTIVE", "INACTIVE"},
    "account_type": {"SAVINGS", "CURRENT", "INTEREST_FREE"},
    "account_status": {"ACTIVE", "DORMANT", "CLOSED"},
    "currency": {"ETB"},
    "transaction_type": {"DEPOSIT", "WITHDRAWAL", "TRANSFER", "PAYMENT"},
    "channel": {"BRANCH", "MOBILE", "USSD", "INTERNET", "CARD"},
    "txn_status": {"COMPLETED", "PENDING", "FAILED"},
    "operation": {"INSERT", "UPDATE"},
}
MAX_AMOUNT = 10_000_000.00  # upper bound for a single transaction in this prototype
RE = {
    "customer_id": re.compile(r"^C\d{6}$"),
    "account_id": re.compile(r"^A\d{6}$"),
    "transaction_id": re.compile(r"^T\d{8}$"),
    "event_id": re.compile(r"^E\d{6}$"),
    "region_code": re.compile(r"^R\d{2}$"),
    "date": re.compile(r"^\d{4}-\d{2}-\d{2}$"),
    "ts": re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$"),
    "money": re.compile(r"^-?\d{1,16}\.\d{2}$"),  # fits DECIMAL(18,2)
}


def parse_date(s):
    if not isinstance(s, str) or not RE["date"].match(s):
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


def parse_ts(s):
    if not isinstance(s, str) or not RE["ts"].match(s):
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        return None


def few(items, n=3):
    items = list(items)
    return ", ".join(map(str, items[:n])) + (" ..." if len(items) > n else "")


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.reader(f)
        header = next(r, [])
        rows = [dict(zip(header, row + [""] * (len(header) - len(row)))) for row in r]
    return header, rows


def read_jsonl(path):
    events, broken = [], []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f, start=1):
            if not line.strip():
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                broken.append(i)
    return events, broken


def run_checks(paths, manifest, results):

    def check(group, name, bad, detail_ok=""):
        bad = list(bad)
        results.append((group, name, not bad, f"{len(bad)} problem(s): {few(bad)}" if bad else detail_ok))

    c_head, customers = read_csv(paths["customers"])
    a_head, accounts = read_csv(paths["accounts"])
    t_head, txns = read_csv(paths["transactions"])
    events, broken_lines = read_jsonl(paths["cdc"])

    # 1. Primary keys
    g = "1 Primary keys"
    for label, rows, key in [("customers", customers, "customer_id"), ("accounts", accounts, "account_id"),
                             ("transactions", txns, "transaction_id")]:
        seen, dups = set(), []
        for r in rows:
            k = r.get(key, "")
            if k in seen:
                dups.append(k)
            seen.add(k)
        check(g, f"{label}.{key} unique", dups, f"{len(rows):,} rows")
        check(g, f"{label}.{key} not missing and matches pattern",
              [r.get(key) or "<empty>" for r in rows if not RE[key].match(r.get(key, ""))])
    ids = [e.get("event_id") for e in events]
    check(g, "cdc event_id unique", sorted({i for i in ids if ids.count(i) > 1}), f"{len(ids):,} events")
    check(g, "cdc event_id not missing and matches pattern", [i for i in ids if not RE["event_id"].match(str(i))])

    # 2. Referential integrity
    g = "2 Referential integrity"
    cust_ids = {c["customer_id"] for c in customers}
    acct = {a["account_id"]: a for a in accounts}
    check(g, "every account -> existing customer", [a["account_id"] for a in accounts if a["customer_id"] not in cust_ids])
    check(g, "every transaction -> existing account", [t["transaction_id"] for t in txns if t["account_id"] not in acct])
    check(g, "every CDC after-record -> existing account",
          [e.get("event_id") for e in events if isinstance(e.get("after"), dict) and e["after"].get("account_id") not in acct])

    # 3. Required columns
    g = "3 Required columns"
    for label, head, expected, rows in [("customers", c_head, CUSTOMER_COLS, customers),
                                        ("accounts", a_head, ACCOUNT_COLS, accounts),
                                        ("transactions", t_head, TXN_COLS, txns)]:
        check(g, f"{label}.csv header is exactly {len(expected)} agreed columns", [] if head == expected else [f"got {head}"])
        check(g, f"{label}: no empty required values",
              [f"{r.get(expected[0])}.{c}" for r in rows for c in expected if r.get(c, "") == ""])
    check(g, "cdc: every line is valid JSON", [f"line {n}" for n in broken_lines])
    check(g, "cdc: every event has exactly the agreed keys",
          [e.get("event_id") for e in events if not (CDC_KEYS <= set(e) <= CDC_KEYS | CDC_OPTIONAL)])
    rec_bad = []
    for e in events:
        for side in ("before", "after"):
            rec = e.get(side)
            if rec is not None and (not isinstance(rec, dict) or list(rec.keys()) != TXN_COLS
                                    or any(v in ("", None) for v in rec.values())):
                rec_bad.append(f"{e.get('event_id')}.{side}")
    check(g, "cdc: before/after records use the exact transaction schema, no empty fields", rec_bad)

    # 4. Types and formats
    g = "4 Types and formats"
    check(g, "customers.registration_date is a valid YYYY-MM-DD",
          [c["customer_id"] for c in customers if parse_date(c["registration_date"]) is None])
    check(g, "customers.region_code looks like R01", [c["customer_id"] for c in customers if not RE["region_code"].match(c["region_code"])])
    check(g, "accounts.opened_date is a valid YYYY-MM-DD",
          [a["account_id"] for a in accounts if parse_date(a["opened_date"]) is None])
    check(g, "transactions.event_ts is ISO 8601 UTC with Z",
          [t["transaction_id"] for t in txns if parse_ts(t["event_ts"]) is None])
    check(g, "transactions.txn_date is a valid YYYY-MM-DD",
          [t["transaction_id"] for t in txns if parse_date(t["txn_date"]) is None])
    check(g, "transactions.amount has exactly 2 decimals and fits DECIMAL(18,2)",
          [t["transaction_id"] for t in txns if not RE["money"].match(t["amount"])])
    cdc_fmt = []
    for e in events:
        if parse_ts(e.get("event_time")) is None:
            cdc_fmt.append(f"{e.get('event_id')}.event_time")
        for side in ("before", "after"):
            rec = e.get(side)
            if isinstance(rec, dict):
                if parse_ts(rec.get("event_ts")) is None or parse_date(rec.get("txn_date")) is None \
                        or not RE["money"].match(str(rec.get("amount"))):
                    cdc_fmt.append(f"{e.get('event_id')}.{side}")
    check(g, "cdc: event_time / event_ts / txn_date / amount formats", cdc_fmt)
    check(g, "cdc: schema_version = \"1.0\" and entity = \"transactions\"",
          [e.get("event_id") for e in events if e.get("schema_version") != "1.0" or e.get("entity") != "transactions"])

    # 5. Enumerated values
    g = "5 Enumerated values"
    for label, rows, col, key in [
        ("customers", customers, "customer_type", "customer_type"), ("customers", customers, "status", "customer_status"),
        ("accounts", accounts, "account_type", "account_type"), ("accounts", accounts, "status", "account_status"),
        ("accounts", accounts, "currency", "currency"), ("transactions", txns, "currency", "currency"),
        ("transactions", txns, "transaction_type", "transaction_type"), ("transactions", txns, "channel", "channel"),
        ("transactions", txns, "status", "txn_status")]:
        check(g, f"{label}.{col} in {sorted(ALLOWED[key])}", sorted({r[col] for r in rows if r[col] not in ALLOWED[key]}))
    enum_cdc = []
    for e in events:
        for side in ("before", "after"):
            rec = e.get(side)
            if isinstance(rec, dict) and (rec.get("currency") not in ALLOWED["currency"]
                                          or rec.get("transaction_type") not in ALLOWED["transaction_type"]
                                          or rec.get("channel") not in ALLOWED["channel"]
                                          or rec.get("status") not in ALLOWED["txn_status"]):
                enum_cdc.append(f"{e.get('event_id')}.{side}")
    check(g, "cdc records: currency/type/channel/status allowed", enum_cdc)

    # 6. Amounts
    g = "6 Amounts"

    def not_positive(v):
        try:
            return not (0 < float(v) <= MAX_AMOUNT)
        except (TypeError, ValueError):
            return True
    check(g, f"transactions.amount > 0 and <= {MAX_AMOUNT:,.0f} ETB",
          [t["transaction_id"] for t in txns if not_positive(t["amount"])])
    check(g, f"cdc record amounts > 0 and <= {MAX_AMOUNT:,.0f} ETB",
          [e.get("event_id") for e in events for s in ("before", "after")
           if isinstance(e.get(s), dict) and not_positive(e[s].get("amount"))])

    # 10. Chronology
    g = "10 Chronology"
    reg = {c["customer_id"]: parse_date(c["registration_date"]) for c in customers}
    opened = {a["account_id"]: parse_date(a["opened_date"]) for a in accounts}
    check(g, "customer registration_date <= account opened_date",
          [a["account_id"] for a in accounts if reg.get(a["customer_id"]) and opened.get(a["account_id"])
           and opened[a["account_id"]] < reg[a["customer_id"]]])
    early, mismatch = [], []
    for t in txns:
        ts, td = parse_ts(t["event_ts"]), parse_date(t["txn_date"])
        if ts and td and ts.date() != td:
            mismatch.append(t["transaction_id"])
        if td and opened.get(t["account_id"]) and td < opened[t["account_id"]]:
            early.append(t["transaction_id"])
    check(g, "account opened_date <= transaction txn_date", early)
    check(g, "txn_date = UTC date of event_ts", mismatch)
    cdc_chrono = []
    for e in events:
        rec = e.get("after")
        if isinstance(rec, dict):
            ts, td = parse_ts(rec.get("event_ts")), parse_date(rec.get("txn_date"))
            if ts and td and ts.date() != td:
                cdc_chrono.append(e.get("event_id"))
            if td and opened.get(rec.get("account_id")) and td < opened[rec["account_id"]]:
                cdc_chrono.append(e.get("event_id"))
    check(g, "cdc after-records: txn_date = date(event_ts) and >= account opened_date", cdc_chrono)
    times = [e.get("event_time") for e in events]
    out_of_order = [events[i]["event_id"] for i in range(1, len(events))
                    if str(times[i]) < str(times[i - 1])]
    check(g, "cdc events are in event_time order", out_of_order)

    # 7. CDC semantics
    g = "7 CDC semantics"
    check(g, "operation is INSERT or UPDATE", sorted({str(e.get("operation")) for e in events
                                                      if e.get("operation") not in ALLOWED["operation"]}))
    known = {t["transaction_id"] for t in txns}
    latest = {t["transaction_id"]: {c: t[c] for c in TXN_COLS} for t in txns}
    ins_not_new, upd_unknown, shape, rec_mismatch, before_wrong = [], [], [], [], []
    for e in events:
        eid, op, rid = e.get("event_id"), e.get("operation"), e.get("record_id")
        b, a = e.get("before"), e.get("after")
        if op == "INSERT":
            if b is not None or not isinstance(a, dict):
                shape.append(eid)
            if rid in known:
                ins_not_new.append(eid)
        elif op == "UPDATE":
            if not isinstance(b, dict) or not isinstance(a, dict):
                shape.append(eid)
            if rid not in known:
                upd_unknown.append(eid)
            elif isinstance(b, dict) and latest.get(rid) != b:
                before_wrong.append(eid)
        for rec in (b, a):
            if isinstance(rec, dict) and rec.get("transaction_id") != rid:
                rec_mismatch.append(eid)
        if op in ALLOWED["operation"] and isinstance(a, dict):
            known.add(rid)
            latest[rid] = a
    check(g, "INSERT uses a new transaction_id (not in snapshot or earlier INSERT)", ins_not_new)
    check(g, "UPDATE targets a known transaction_id", upd_unknown)
    check(g, "before is null for INSERT; before and after both present for UPDATE", shape)
    check(g, "before/after transaction_id = record_id", sorted(set(rec_mismatch)))
    check(g, "UPDATE before = the previous state of that transaction", before_wrong)

    # 8. Row counts
    g = "8 Row counts"
    if manifest is not None:
        p = manifest["params"]
        for label, actual in [("customers", len(customers)), ("accounts", len(accounts)),
                              ("transactions", len(txns)), ("cdc_events", len(events))]:
            check(g, f"{label} = generator parameter ({p[label]:,})",
                  [] if actual == p[label] else [f"actual {actual:,}"], f"actual {actual:,}")

    # 11. Coverage of values needed by the analytical jobs
    g = "11 Coverage"
    for label, rows, col, key in [("transactions", txns, "transaction_type", "transaction_type"),
                                  ("transactions", txns, "status", "txn_status"),
                                  ("transactions", txns, "channel", "channel"),
                                  ("accounts", accounts, "account_type", "account_type"),
                                  ("customers", customers, "customer_type", "customer_type")]:
        missing = ALLOWED[key] - {r[col] for r in rows}
        check(g, f"all {col} values present in {label}", sorted(missing))
    per_cust = {}
    for a in accounts:
        per_cust[a["customer_id"]] = per_cust.get(a["customer_id"], 0) + 1
    multi = sum(1 for v in per_cust.values() if v > 1)
    check(g, "some customers have more than one account", [] if multi else ["none"], f"{multi} customers")
    days = {t["txn_date"] for t in txns}
    check(g, "transactions span multiple dates", [] if len(days) > 1 else ["only one date"], f"{len(days)} dates")
    st = {s: sum(t["status"] == s for t in txns) for s in ALLOWED["txn_status"]}
    check(g, "COMPLETED is the majority, PENDING/FAILED smaller but present",
          [] if st["COMPLETED"] > st["PENDING"] + st["FAILED"] and st["PENDING"] and st["FAILED"] else [str(st)],
          ", ".join(f"{k}={v}" for k, v in sorted(st.items())))
    ops = {o: sum(e.get("operation") == o for e in events) for o in ALLOWED["operation"]}
    check(g, "cdc feed has both INSERT and UPDATE events", [o for o, n in ops.items() if n == 0],
          ", ".join(f"{k}={v}" for k, v in sorted(ops.items())))
    return customers, accounts, txns, events


def reproducibility(data_dir, manifest, results):
    """Re-runs the generator with the same parameters and compares file hashes."""
    p = manifest["params"]
    tmp = tempfile.mkdtemp(prefix="m5_repro_")
    try:
        cmd = [sys.executable, os.path.join(HERE, "generate_synthetic_data.py"), "--seed", str(p["seed"]),
               "--customers", str(p["customers"]), "--accounts", str(p["accounts"]),
               "--transactions", str(p["transactions"]), "--cdc-events", str(p["cdc_events"]),
               "--start", p["start"], "--days", str(p["days"]), "--out", tmp, "--no-fixtures"]
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL)
        with open(os.path.join(tmp, "manifest.json"), encoding="utf-8") as f:
            rerun = json.load(f)
        for fname, h in manifest["sha256"].items():
            from_disk = rerun["sha256"][fname]
            results.append(("9 Reproducibility", f"re-run with seed {p['seed']} gives identical {fname}",
                            from_disk == h, f"sha256 {h[:16]}..." if from_disk == h else "hash differs"))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def profile(customers, accounts, txns, events):
    lines = ["", "Dataset profile (informational)"]
    per_cust = {}
    for a in accounts:
        per_cust[a["customer_id"]] = per_cust.get(a["customer_id"], 0) + 1
    dist = {}
    for v in per_cust.values():
        dist[v] = dist.get(v, 0) + 1
    lines.append("  accounts per customer: " + ", ".join(f"{k} acct={v} cust" for k, v in sorted(dist.items())))
    for label, rows, col in [("customer_type", customers, "customer_type"), ("customer status", customers, "status"),
                             ("account_type", accounts, "account_type"), ("account status", accounts, "status"),
                             ("transaction_type", txns, "transaction_type"), ("channel", txns, "channel"),
                             ("txn status", txns, "status")]:
        c = {}
        for r in rows:
            c[r[col]] = c.get(r[col], 0) + 1
        lines.append(f"  {label:<17}" + ", ".join(f"{k}={v:,}" for k, v in sorted(c.items(), key=lambda x: -x[1])))
    comp = [float(t["amount"]) for t in txns if t["status"] == "COMPLETED"]
    amts = sorted(float(t["amount"]) for t in txns)
    lines.append(f"  amount ETB (all):  min {amts[0]:,.2f} | median {amts[len(amts) // 2]:,.2f} | max {amts[-1]:,.2f}")
    lines.append(f"  COMPLETED only:    {len(comp):,} txns, total {sum(comp):,.2f} ETB")
    lines.append(f"  amounts >= 100,000 ETB: {sum(a >= 100000 for a in amts)} txns (illustrative high-value cases, not a real rule)")
    days = sorted({t["txn_date"] for t in txns})
    lines.append(f"  txn_date range:    {days[0]} to {days[-1]} ({len(days)} days)")
    lines.append(f"  cdc event_time:    {events[0]['event_time']} to {events[-1]['event_time']}")
    return lines


def default_paths(d):
    return {"customers": os.path.join(d, "customers.csv"), "accounts": os.path.join(d, "accounts.csv"),
            "transactions": os.path.join(d, "transactions.csv"), "cdc": os.path.join(d, "cdc_events.jsonl")}


def fixture_test(data_dir, manifest):
    """Substitutes each fixture for the normal file and confirms that at least one check fails."""
    lines = ["", "=" * 78, "FIXTURE TEST - do the checks catch the deliberately invalid files?", "=" * 78]
    all_caught = True
    for key, fname in [("accounts", "accounts_invalid.csv"), ("transactions", "transactions_invalid.csv"),
                       ("cdc", "cdc_events_invalid.jsonl")]:
        path = os.path.join(data_dir, "tests", fname)
        if not os.path.exists(path):
            lines.append(f"  {fname}: not found (run the generator without --no-fixtures)")
            all_caught = False
            continue
        paths = default_paths(data_dir)
        paths[key] = path
        res = []
        run_checks(paths, None, res)  # row counts are skipped for fixtures
        failed = [r for r in res if not r[2]]
        all_caught &= bool(failed)
        lines.append(f"\n  {fname}: {len(failed)} check(s) failed -> {'CAUGHT' if failed else 'NOT CAUGHT'}")
        for grp, name, _, detail in failed:
            lines.append(f"     [{grp}] {name}  ({detail})")
    lines.append("\nFIXTURE RESULT: " + ("every invalid file was detected" if all_caught else "SOMETHING WAS NOT DETECTED"))
    return lines, all_caught


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--report", default="docs/validation_results.txt")
    ap.add_argument("--fixtures", action="store_true", help="also run the invalid test files and confirm they get caught")
    ap.add_argument("--skip-repro", action="store_true", help="skip the re-run reproducibility check")
    args = ap.parse_args()

    with open(os.path.join(args.data, "manifest.json"), encoding="utf-8") as f:
        manifest = json.load(f)
    results = []
    customers, accounts, txns, events = run_checks(default_paths(args.data), manifest, results)
    if not args.skip_repro:
        reproducibility(args.data, manifest, results)

    out = [f"Data quality validation - {args.data}/",
           f"Run at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} (local time)",
           f"Generator parameters: {json.dumps(manifest['params'])}",
           "-" * 78]
    order = sorted({r[0] for r in results}, key=lambda g: int(g.split()[0]))
    for grp in order:
        out.append(f"\n{grp}")
        for g, name, ok, detail in results:
            if g == grp:
                out.append(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))
    out += profile(customers, accounts, txns, events)
    passed = sum(r[2] for r in results)
    failed = len(results) - passed
    out += ["-" * 78, f"RESULT: {passed} passed, {failed} failed -> {'ALL CHECKS PASSED' if failed == 0 else 'FAILED'}"]
    ok = failed == 0
    if args.fixtures:
        fl, caught = fixture_test(args.data, manifest)
        out += fl
        ok = ok and caught

    text = "\n".join(out) + "\n"
    print(text)
    os.makedirs(os.path.dirname(args.report) or ".", exist_ok=True)
    with open(args.report, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    print(f"saved to {args.report}")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
