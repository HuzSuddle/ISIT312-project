"""
Synthetic banking data generator for the ISIT312 data lake prototype.

Produces customers, accounts, transactions and a simulated CDC event feed.
All values are fictional. Output is deterministic for a given seed and set of arguments.

Usage:
    python code/generate_synthetic_data.py                # default: 200 / 300 / 2,000 / 100
    python code/generate_synthetic_data.py --size large   # 2,000 / 3,000 / 20,000 / 1,000
"""

import argparse
import copy
import csv
import hashlib
import json
import math
import os
import random
from datetime import date, datetime, timedelta, timezone

SCHEMA_VERSION = "1.0"
DEFAULT_SEED = 312

SIZES = {
    "small": {"customers": 200, "accounts": 300, "transactions": 2000, "cdc_events": 100},
    "large": {"customers": 2000, "accounts": 3000, "transactions": 20000, "cdc_events": 1000},
}

CUSTOMER_COLS = ["customer_id", "customer_type", "region_code", "registration_date", "status"]
ACCOUNT_COLS = ["account_id", "customer_id", "account_type", "opened_date", "currency", "status"]
TXN_COLS = ["transaction_id", "account_id", "event_ts", "txn_date", "amount", "currency",
            "transaction_type", "channel", "status"]

# Distribution weights are assumptions; the bank did not provide these figures.
CUSTOMER_TYPES = [("RETAIL", 0.85), ("MSME", 0.15)]
CUSTOMER_STATUS = [("ACTIVE", 0.95), ("INACTIVE", 0.05)]
REGION_CODES = [f"R{i:02d}" for i in range(1, 13)]
ACCOUNT_TYPES_RETAIL = [("SAVINGS", 0.60), ("INTEREST_FREE", 0.20), ("CURRENT", 0.20)]
ACCOUNT_TYPES_MSME = [("CURRENT", 0.70), ("SAVINGS", 0.15), ("INTEREST_FREE", 0.15)]
ACCOUNT_STATUS = [("ACTIVE", 0.88), ("DORMANT", 0.09), ("CLOSED", 0.03)]

CHANNELS = [("MOBILE", 0.38), ("BRANCH", 0.22), ("USSD", 0.18), ("CARD", 0.14), ("INTERNET", 0.08)]
TYPES_BY_CHANNEL = {
    "BRANCH": ["DEPOSIT", "DEPOSIT", "WITHDRAWAL", "TRANSFER"],
    "MOBILE": ["TRANSFER", "PAYMENT", "PAYMENT"],
    "USSD": ["TRANSFER", "PAYMENT"],
    "INTERNET": ["TRANSFER", "PAYMENT"],
    "CARD": ["WITHDRAWAL", "PAYMENT"],
}
TXN_STATUS = [("COMPLETED", 0.90), ("FAILED", 0.06), ("PENDING", 0.04)]

TYPICAL_AMOUNT = {"DEPOSIT": 3500, "WITHDRAWAL": 2000, "TRANSFER": 2500, "PAYMENT": 600}
HIGH_VALUE_SHARE = 0.015

# Hourly weights in UTC, reflecting business hours in Addis Ababa (UTC+3).
UTC_HOUR_WEIGHTS = [2, 2, 1, 1, 3, 6, 9, 10, 10, 10, 10, 10, 10, 9, 9, 8, 7, 5, 3, 2, 1, 1, 1, 1]


def pick(rng, weighted):
    return rng.choices([v for v, _ in weighted], weights=[w for _, w in weighted], k=1)[0]


def random_date(rng, start, end):
    return start + timedelta(days=rng.randint(0, (end - start).days))


def iso_utc(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def money(x):
    return f"{x:.2f}"


def make_amount(rng, ttype):
    """Log-normal amount per transaction type, with a small share of high-value transactions."""
    if ttype in ("DEPOSIT", "TRANSFER") and rng.random() < HIGH_VALUE_SHARE:
        return round(rng.uniform(200_000, 2_000_000), 2)
    amt = rng.lognormvariate(math.log(TYPICAL_AMOUNT[ttype]), 1.0)
    return round(min(max(amt, 1.00), 150_000), 2)


def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(header)
        w.writerows(rows)


def write_jsonl(path, events):
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        for e in events:
            f.write(json.dumps(e, separators=(",", ":")) + "\n")


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def make_customers(rng, n, last_reg_date):
    rows = []
    for i in range(1, n + 1):
        rows.append([
            f"C{i:06d}",
            pick(rng, CUSTOMER_TYPES),
            rng.choice(REGION_CODES),
            random_date(rng, date(2015, 1, 1), last_reg_date).isoformat(),
            pick(rng, CUSTOMER_STATUS),
        ])
    return rows


def make_accounts(rng, customers, n, last_open_date):
    """Each customer receives one account; remaining accounts are assigned at random."""
    owners = [c for c in customers]
    if n >= len(customers):
        assigned = list(owners) + [rng.choice(owners) for _ in range(n - len(owners))]
    else:
        assigned = rng.sample(owners, n)
    assigned.sort(key=lambda c: c[0])

    rows = []
    for i, cust in enumerate(assigned, start=1):
        cust_id, ctype, _, reg_date, cstatus = cust
        atype = pick(rng, ACCOUNT_TYPES_MSME if ctype == "MSME" else ACCOUNT_TYPES_RETAIL)
        opened = random_date(rng, date.fromisoformat(reg_date), last_open_date)
        if cstatus == "INACTIVE":
            astatus = rng.choice(["DORMANT", "CLOSED"])
        else:
            astatus = pick(rng, ACCOUNT_STATUS)
        rows.append([f"A{i:06d}", cust_id, atype, opened.isoformat(), "ETB", astatus])
    return rows


def random_txn(rng, account, when):
    channel = pick(rng, CHANNELS)
    ttype = rng.choice(TYPES_BY_CHANNEL[channel])
    return {
        "transaction_id": None,
        "account_id": account[0],
        "event_ts": iso_utc(when),
        "txn_date": when.date().isoformat(),
        "amount": money(make_amount(rng, ttype)),
        "currency": "ETB",
        "transaction_type": ttype,
        "channel": channel,
        "status": None,
    }


def random_time_in_day(rng, day_start):
    hour = rng.choices(range(24), weights=UTC_HOUR_WEIGHTS, k=1)[0]
    return day_start + timedelta(hours=hour, seconds=rng.randrange(3600))


def make_transactions(rng, accounts, n, start, days):
    """Transactions are generated for ACTIVE accounts only and numbered in time order."""
    active = [a for a in accounts if a[5] == "ACTIVE"]
    if not active:
        raise SystemExit("no ACTIVE accounts generated - increase --accounts")
    t0 = datetime(start.year, start.month, start.day, tzinfo=timezone.utc)
    txns = []
    for _ in range(n):
        acc = rng.choice(active)
        when = random_time_in_day(rng, t0 + timedelta(days=rng.randrange(days)))
        t = random_txn(rng, acc, when)
        t["status"] = pick(rng, TXN_STATUS)
        txns.append(t)
    txns.sort(key=lambda t: (t["event_ts"], t["account_id"], t["amount"]))
    for i, t in enumerate(txns, start=1):
        t["transaction_id"] = f"T{i:08d}"
    return txns


def make_cdc_events(rng, accounts, txns, n, cdc_start):
    """
    Simulated CDC feed on the transactions entity.
    INSERT adds a new transaction; UPDATE settles a PENDING transaction as COMPLETED or FAILED.
    """
    active = [a for a in accounts if a[5] == "ACTIVE"]
    state = {t["transaction_id"]: dict(t) for t in txns}
    pending = [t["transaction_id"] for t in txns if t["status"] == "PENDING"]
    next_num = len(txns) + 1
    clock = cdc_start
    events = []
    for i in range(1, n + 1):
        clock += timedelta(seconds=rng.randint(5, 60))
        do_update = pending and rng.random() < 0.30
        if do_update:
            tid = pending.pop(rng.randrange(len(pending)))
            before = dict(state[tid])
            after = dict(before)
            after["status"] = "COMPLETED" if rng.random() < 0.8 else "FAILED"
            state[tid] = after
            ev = {"record_id": tid, "operation": "UPDATE", "before": before, "after": after}
        else:
            acc = rng.choice(active)
            when = clock - timedelta(seconds=rng.randint(5, 90))
            t = random_txn(rng, acc, when)
            t["transaction_id"] = f"T{next_num:08d}"
            t["status"] = pick(rng, [("COMPLETED", 0.80), ("PENDING", 0.15), ("FAILED", 0.05)])
            next_num += 1
            state[t["transaction_id"]] = t
            if t["status"] == "PENDING":
                pending.append(t["transaction_id"])
            ev = {"record_id": t["transaction_id"], "operation": "INSERT", "before": None, "after": dict(t)}
        events.append({
            "event_id": f"E{i:06d}",
            "schema_version": SCHEMA_VERSION,
            "entity": "transactions",
            "source": "SIMULATED_CDC",
            "record_id": ev["record_id"],
            "operation": ev["operation"],
            "event_time": iso_utc(clock),
            "before": ev["before"],
            "after": ev["after"],
        })
    return events


def make_test_fixtures(rng, out_dir, customers, accounts, txns, events):
    """Writes copies of the datasets with known defects to data/tests/ for testing the validation script."""
    tdir = os.path.join(out_dir, "tests")
    os.makedirs(tdir, exist_ok=True)
    notes = []

    acc_bad = [list(a) for a in accounts]
    acc_bad.append(["A999901", "C999999", "SAVINGS", "2020-01-01", "ETB", "ACTIVE"])
    notes.append(("accounts_invalid.csv", "A999901", "Customer C999999 does not exist", "Referential integrity"))
    acc_bad.append(list(accounts[0]))
    notes.append(("accounts_invalid.csv", accounts[0][0], "Duplicate account_id", "Primary keys"))
    acc_bad.append(["A999902", customers[0][0], "GOLD", customers[0][3], "ETB", "ACTIVE"])
    notes.append(("accounts_invalid.csv", "A999902", "Invalid account_type (GOLD)", "Enumerated values"))
    acc_bad.append(["A999903", customers[1][0], "SAVINGS", "2014-12-31", "ETB", "ACTIVE"])
    notes.append(("accounts_invalid.csv", "A999903", "Opened before customer registration", "Chronology"))
    write_csv(os.path.join(tdir, "accounts_invalid.csv"), ACCOUNT_COLS, acc_bad)

    rows = [[t[c] for c in TXN_COLS] for t in txns]
    base = rows[len(rows) // 2]

    def bad(tid, **changes):
        r = dict(zip(TXN_COLS, base))
        r["transaction_id"] = tid
        r.update(changes)
        return [r[c] for c in TXN_COLS]

    tx_bad = [list(r) for r in rows]
    tx_bad.append(list(rows[10]))
    notes.append(("transactions_invalid.csv", rows[10][0], "Duplicate transaction_id", "Primary keys"))
    tx_bad.append(bad("T99999901", account_id="A999999"))
    notes.append(("transactions_invalid.csv", "T99999901", "Account A999999 does not exist", "Referential integrity"))
    tx_bad.append(bad("T99999902", status="DONE"))
    notes.append(("transactions_invalid.csv", "T99999902", "Invalid status (DONE)", "Enumerated values"))
    tx_bad.append(bad("T99999903", event_ts="31/10/2026 25:61"))
    notes.append(("transactions_invalid.csv", "T99999903", "Malformed event_ts", "Types and formats"))
    tx_bad.append(bad("T99999904", amount="-150.00"))
    notes.append(("transactions_invalid.csv", "T99999904", "Negative amount", "Amounts"))
    tx_bad.append(bad("T99999905", amount="150.5"))
    notes.append(("transactions_invalid.csv", "T99999905", "Amount with one decimal place", "Types and formats"))
    tx_bad.append(bad("T99999906", txn_date="2026-10-02", event_ts="2026-10-01T23:30:00Z"))
    notes.append(("transactions_invalid.csv", "T99999906", "txn_date does not match event_ts", "Chronology"))
    tx_bad.append(bad("T99999907", amount=""))
    notes.append(("transactions_invalid.csv", "T99999907", "Missing amount", "Required columns"))
    write_csv(os.path.join(tdir, "transactions_invalid.csv"), TXN_COLS, tx_bad)

    ev_bad = [copy.deepcopy(e) for e in events]
    for idx in sorted(rng.sample(range(len(events)), 2)):
        ev_bad.append(copy.deepcopy(events[idx]))
        notes.append(("cdc_events_invalid.jsonl", events[idx]["event_id"], "Duplicate event", "Primary keys"))
    late = ev_bad.pop(len(events) - 3)
    ev_bad.insert(5, late)
    notes.append(("cdc_events_invalid.jsonl", late["event_id"], "Out-of-order event", "Chronology"))
    e = copy.deepcopy(events[0]); e["event_id"] = "E999901"; e["operation"] = "DELETE"
    ev_bad.append(e)
    notes.append(("cdc_events_invalid.jsonl", "E999901", "Unsupported operation (DELETE)", "CDC semantics"))
    upd = next(x for x in events if x["operation"] == "UPDATE")
    e = copy.deepcopy(upd); e["event_id"] = "E999902"; e["record_id"] = "T99999999"
    e["before"]["transaction_id"] = "T99999999"; e["after"]["transaction_id"] = "T99999999"
    ev_bad.append(e)
    notes.append(("cdc_events_invalid.jsonl", "E999902", "UPDATE for an unknown transaction", "CDC semantics"))
    ins = next(x for x in events if x["operation"] == "INSERT")
    e = copy.deepcopy(ins); e["event_id"] = "E999903"; e["record_id"] = txns[0]["transaction_id"]
    e["after"]["transaction_id"] = txns[0]["transaction_id"]
    ev_bad.append(e)
    notes.append(("cdc_events_invalid.jsonl", "E999903", "INSERT reuses an existing ID", "CDC semantics"))
    write_jsonl(os.path.join(tdir, "cdc_events_invalid.jsonl"), ev_bad)

    with open(os.path.join(tdir, "README.md"), "w", encoding="utf-8", newline="\n") as f:
        f.write("# Test fixtures\n\n")
        f.write("These files are copies of the normal datasets with known defects added. They are used to confirm "
                "that the validation script detects invalid data (`python code/validate_data.py --fixtures`) "
                "and should not be loaded as the main dataset.\n\n")
        f.write("| File | Record | Defect | Detected by |\n|---|---|---|---|\n")
        for fn, rec, prob, chk in notes:
            f.write(f"| {fn} | {rec} | {prob} | {chk} |\n")


def main():
    ap = argparse.ArgumentParser(description="Generate the synthetic banking dataset for the ISIT312 prototype")
    ap.add_argument("--seed", type=int, default=DEFAULT_SEED)
    ap.add_argument("--size", choices=SIZES.keys(), default="small")
    ap.add_argument("--customers", type=int)
    ap.add_argument("--accounts", type=int)
    ap.add_argument("--transactions", type=int)
    ap.add_argument("--cdc-events", type=int)
    ap.add_argument("--start", default="2026-10-01", help="first day of the transaction period (UTC)")
    ap.add_argument("--days", type=int, default=31)
    ap.add_argument("--out", default="data")
    ap.add_argument("--no-fixtures", action="store_true", help="do not write data/tests/")
    args = ap.parse_args()

    counts = dict(SIZES[args.size])
    for k in counts:
        v = getattr(args, k)
        if v is not None:
            counts[k] = v
    if min(counts.values()) < 1:
        raise SystemExit("all counts must be at least 1")

    rng = random.Random(args.seed)
    start = date.fromisoformat(args.start)
    end = start + timedelta(days=args.days - 1)
    os.makedirs(args.out, exist_ok=True)

    customers = make_customers(rng, counts["customers"], start - timedelta(days=60))
    accounts = make_accounts(rng, customers, counts["accounts"], start - timedelta(days=1))
    txns = make_transactions(rng, accounts, counts["transactions"], start, args.days)
    cdc_start = datetime(end.year, end.month, end.day, tzinfo=timezone.utc) + timedelta(days=1, hours=6)
    events = make_cdc_events(rng, accounts, txns, counts["cdc_events"], cdc_start)

    write_csv(os.path.join(args.out, "customers.csv"), CUSTOMER_COLS, customers)
    write_csv(os.path.join(args.out, "accounts.csv"), ACCOUNT_COLS, accounts)
    write_csv(os.path.join(args.out, "transactions.csv"), TXN_COLS, [[t[c] for c in TXN_COLS] for t in txns])
    write_jsonl(os.path.join(args.out, "cdc_events.jsonl"), events)
    if not args.no_fixtures:
        make_test_fixtures(random.Random(args.seed + 1), args.out, customers, accounts, txns, events)

    files = ["customers.csv", "accounts.csv", "transactions.csv", "cdc_events.jsonl"]
    mix = {"INSERT": sum(e["operation"] == "INSERT" for e in events),
           "UPDATE": sum(e["operation"] == "UPDATE" for e in events)}
    manifest = {
        "generator": "code/generate_synthetic_data.py",
        "schema_version": SCHEMA_VERSION,
        "note": "SYNTHETIC DATA - every value is fictional; CDC events are simulated, the bank has no log-based CDC",
        "params": {"seed": args.seed, "size": args.size, **counts, "start": args.start, "days": args.days},
        "snapshot_period_utc": {"from": start.isoformat(), "to": end.isoformat()},
        "row_counts": {"customers": len(customers), "accounts": len(accounts),
                       "transactions": len(txns), "cdc_events": len(events)},
        "cdc_event_mix": mix,
        "sha256": {f: sha256_of(os.path.join(args.out, f)) for f in files},
    }
    with open(os.path.join(args.out, "manifest.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(manifest, f, indent=2)
        f.write("\n")

    print(f"done -> {args.out}/  (seed={args.seed})")
    for k, v in manifest["row_counts"].items():
        print(f"  {k:<13} {v:>8,}")
    print(f"  cdc mix       INSERT={mix['INSERT']}  UPDATE={mix['UPDATE']}")


if __name__ == "__main__":
    main()
