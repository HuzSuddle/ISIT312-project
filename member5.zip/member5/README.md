# Synthetic Data, Data Model and Quality Checks

This package contains the synthetic banking dataset used throughout the data lake prototype, together with the code that generates and validates it and the supporting documentation. The schema follows the one agreed for the target architecture. No real bank data is included.

## Quick start

```
python code/generate_synthetic_data.py
python code/validate_data.py --fixtures
```

Only Python 3.8 or later is required. No additional packages are needed.

## Contents

| Path | Description |
|---|---|
| `code/generate_synthetic_data.py` | Deterministic data generator (default seed 312) |
| `code/validate_data.py` | Data quality checks (68 checks) |
| `code/make_sample_rows.py` | Produces the sample row extracts |
| `data/` | customers.csv (200), accounts.csv (300), transactions.csv (2,000), cdc_events.jsonl (100), manifest.json |
| `data/tests/` | Test fixtures containing known defects |
| `docs/data_dictionary.md` | Field-level data dictionary |
| `docs/lineage_mapping.md` | Mapping from source files to HDFS paths and Hive tables |
| `docs/data_model_erd.png` | Entity-relationship diagram (editable source: `.mmd`) |
| `docs/sample_rows.md` | Ten sample rows per table and example CDC events |
| `docs/generator_readme.md` | Run instructions and options |
| `docs/validation_results.txt` | Validation output for the default dataset |
| `docs/validation_results_large.txt` | Validation output for the large dataset |
| `docs/reproducibility_check.txt` | Evidence that repeated runs produce identical files |
| `docs/handover_notes.md` | Usage notes for the downstream components |
| `report/` | Report section on the data model and synthetic data |
| `slides/` | Presentation slides |

## Coverage of the work package

1. **Sample banking entities.** Customers, accounts and transactions with stable identifiers and documented keys.
2. **Schema contract.** Column names, types, formats and date conventions are defined in the data dictionary.
3. **Deterministic data.** A parameterised generator with a fixed seed and both a default and a large dataset.
4. **CDC events.** A separate, ordered event feed, clearly labelled as simulated.
5. **Quality checks.** A single-command validation script with saved output.
6. **Data lineage.** The ERD, data dictionary, sample extracts and the file-to-lake mapping, released as version 1.0.
