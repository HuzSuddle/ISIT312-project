# Data Lineage Mapping

This document traces each synthetic source file to its location in the data lake and the Hive table it populates. The HDFS paths and table names follow the agreed architecture. The Hive types listed are recommendations based on the file formats. The final table definitions are part of the batch pipeline.

## Data flow

```
customers.csv     -> /bank_lake/raw/customers/     -> cleaned -> bank_customers
accounts.csv      -> /bank_lake/raw/accounts/      -> cleaned -> bank_accounts
transactions.csv  -> /bank_lake/raw/transactions/  -> cleaned -> bank_transactions -> curated reporting
cdc_events.jsonl  -> /bank_lake/raw/cdc/           -> near_real_time_demo (streaming prototype)
customer_id       -> customer summary              -> HBase lookup table
```

| Zone | Role |
|---|---|
| Raw | Holds the files exactly as generated, so the hashes in `manifest.json` remain valid |
| Cleaned | Data types are applied and invalid records are rejected |
| Curated | Holds the reporting datasets |

## customers.csv to bank_customers

| Column | Example | Recommended Hive type |
|---|---|---|
| customer_id | C000001 | STRING |
| customer_type | RETAIL | STRING |
| region_code | R11 | STRING |
| registration_date | 2023-07-26 | DATE |
| status | ACTIVE | STRING |

## accounts.csv to bank_accounts

| Column | Example | Recommended Hive type |
|---|---|---|
| account_id | A000001 | STRING |
| customer_id | C000001 | STRING (join key to bank_customers) |
| account_type | SAVINGS | STRING |
| opened_date | 2024-03-02 | DATE |
| currency | ETB | STRING |
| status | ACTIVE | STRING |

## transactions.csv to bank_transactions

| Column | Example | Recommended Hive type |
|---|---|---|
| transaction_id | T00000001 | STRING |
| account_id | A000107 | STRING (join key to bank_accounts) |
| event_ts | 2026-10-15T14:23:40Z | STRING in raw, TIMESTAMP after cleaning |
| txn_date | 2026-10-15 | DATE (candidate partition column) |
| amount | 12068.17 | DECIMAL(18,2) |
| currency | ETB | STRING |
| transaction_type | DEPOSIT | STRING |
| channel | BRANCH | STRING |
| status | COMPLETED | STRING |

Hive does not parse the ISO 8601 `T` and `Z` format directly as a TIMESTAMP. The value can be converted during cleaning:
- in Hive, with `from_unixtime(unix_timestamp(event_ts, "yyyy-MM-dd'T'HH:mm:ss'Z'"))`
- in Spark, with `to_timestamp`

## cdc_events.jsonl to the streaming prototype

The `after` record of each event contains the same nine fields as `transactions.csv` and maps to the same columns.
- An INSERT adds a row.
- An UPDATE replaces the existing row.
- `event_id` is used for deduplication, and `event_time` is used for ordering.

## Versioning

| Item | Value |
|---|---|
| Schema version | 1.0 |
| Dataset release | 1.0 (seed 312) |

Any change to column definitions would require a new schema version and a regenerated dataset.
