# Sample rows

The first 10 rows of each file in the default dataset (seed 312). All values are fictional.

## customers.csv

| customer_id | customer_type | region_code | registration_date | status |
|---|---|---|---|---|
| C000001 | RETAIL | R11 | 2023-07-26 | ACTIVE |
| C000002 | RETAIL | R04 | 2019-04-27 | ACTIVE |
| C000003 | MSME | R02 | 2021-09-05 | ACTIVE |
| C000004 | RETAIL | R03 | 2015-02-16 | ACTIVE |
| C000005 | MSME | R12 | 2018-08-29 | ACTIVE |
| C000006 | RETAIL | R01 | 2022-03-26 | ACTIVE |
| C000007 | RETAIL | R03 | 2023-09-15 | ACTIVE |
| C000008 | RETAIL | R02 | 2025-05-03 | ACTIVE |
| C000009 | RETAIL | R08 | 2022-04-16 | ACTIVE |
| C000010 | RETAIL | R04 | 2015-07-13 | ACTIVE |

## accounts.csv

| account_id | customer_id | account_type | opened_date | currency | status |
|---|---|---|---|---|---|
| A000001 | C000001 | SAVINGS | 2024-03-02 | ETB | ACTIVE |
| A000002 | C000002 | SAVINGS | 2021-11-05 | ETB | ACTIVE |
| A000003 | C000003 | INTEREST_FREE | 2022-12-03 | ETB | DORMANT |
| A000004 | C000004 | SAVINGS | 2018-03-01 | ETB | ACTIVE |
| A000005 | C000005 | SAVINGS | 2023-03-05 | ETB | ACTIVE |
| A000006 | C000005 | CURRENT | 2022-10-28 | ETB | ACTIVE |
| A000007 | C000005 | SAVINGS | 2022-11-06 | ETB | ACTIVE |
| A000008 | C000006 | INTEREST_FREE | 2024-04-03 | ETB | ACTIVE |
| A000009 | C000006 | SAVINGS | 2023-04-03 | ETB | ACTIVE |
| A000010 | C000007 | CURRENT | 2024-06-12 | ETB | ACTIVE |

## transactions.csv

| transaction_id | account_id | event_ts | txn_date | amount | currency | transaction_type | channel | status |
|---|---|---|---|---|---|---|---|---|
| T00000001 | A000161 | 2026-10-01T01:34:58Z | 2026-10-01 | 482.50 | ETB | PAYMENT | MOBILE | COMPLETED |
| T00000002 | A000038 | 2026-10-01T02:35:21Z | 2026-10-01 | 8259.55 | ETB | TRANSFER | MOBILE | COMPLETED |
| T00000003 | A000155 | 2026-10-01T05:32:22Z | 2026-10-01 | 2705.08 | ETB | TRANSFER | MOBILE | COMPLETED |
| T00000004 | A000138 | 2026-10-01T05:40:43Z | 2026-10-01 | 3463.95 | ETB | TRANSFER | USSD | PENDING |
| T00000005 | A000231 | 2026-10-01T06:00:11Z | 2026-10-01 | 824.40 | ETB | TRANSFER | BRANCH | COMPLETED |
| T00000006 | A000009 | 2026-10-01T06:17:13Z | 2026-10-01 | 1742.14 | ETB | PAYMENT | USSD | COMPLETED |
| T00000007 | A000216 | 2026-10-01T06:26:57Z | 2026-10-01 | 2737.33 | ETB | DEPOSIT | BRANCH | COMPLETED |
| T00000008 | A000145 | 2026-10-01T06:49:34Z | 2026-10-01 | 643.48 | ETB | PAYMENT | MOBILE | COMPLETED |
| T00000009 | A000065 | 2026-10-01T06:50:56Z | 2026-10-01 | 1605.36 | ETB | TRANSFER | MOBILE | COMPLETED |
| T00000010 | A000260 | 2026-10-01T06:54:56Z | 2026-10-01 | 534.99 | ETB | DEPOSIT | BRANCH | FAILED |

## cdc_events.jsonl

Each event is stored on a single line in the file. The examples below are formatted for readability.

### INSERT example (E000004)

```json
{
  "event_id": "E000004",
  "schema_version": "1.0",
  "entity": "transactions",
  "source": "SIMULATED_CDC",
  "record_id": "T00002001",
  "operation": "INSERT",
  "event_time": "2026-11-01T06:03:21Z",
  "before": null,
  "after": {
    "transaction_id": "T00002001",
    "account_id": "A000205",
    "event_ts": "2026-11-01T06:01:56Z",
    "txn_date": "2026-11-01",
    "amount": "5151.56",
    "currency": "ETB",
    "transaction_type": "DEPOSIT",
    "channel": "BRANCH",
    "status": "COMPLETED"
  }
}
```

### UPDATE example (E000001): pending transaction settled

```json
{
  "event_id": "E000001",
  "schema_version": "1.0",
  "entity": "transactions",
  "source": "SIMULATED_CDC",
  "record_id": "T00000964",
  "operation": "UPDATE",
  "event_time": "2026-11-01T06:00:37Z",
  "before": {
    "transaction_id": "T00000964",
    "account_id": "A000107",
    "event_ts": "2026-10-15T14:23:40Z",
    "txn_date": "2026-10-15",
    "amount": "12068.17",
    "currency": "ETB",
    "transaction_type": "DEPOSIT",
    "channel": "BRANCH",
    "status": "PENDING"
  },
  "after": {
    "transaction_id": "T00000964",
    "account_id": "A000107",
    "event_ts": "2026-10-15T14:23:40Z",
    "txn_date": "2026-10-15",
    "amount": "12068.17",
    "currency": "ETB",
    "transaction_type": "DEPOSIT",
    "channel": "BRANCH",
    "status": "COMPLETED"
  }
}
```
