# Usage Notes for Downstream Components

The figures below refer to the default dataset (seed 312). If the data is regenerated with different settings, `data/manifest.json` contains the updated counts.

## Batch ingestion and Hive

- **Files:** `customers.csv` (200 rows), `accounts.csv` (300 rows) and `transactions.csv` (2,000 rows).
- **Header row:** each file has one header row, so `skip.header.line.count = 1` is required.
- **Keys:** `customer_id`, `account_id` and `transaction_id` are unique, and the normal files contain no orphan records.
- **Timestamps:** `event_ts` uses the ISO 8601 UTC format. It can be loaded as a string in the raw zone and converted during cleaning (see `lineage_mapping.md`).
- **Amounts and dates:** amounts always have two decimal places and fit `DECIMAL(18,2)`. Dates use `YYYY-MM-DD`.
- **Partitioning:** the files are not pre-partitioned. `txn_date` covers 1 to 31 October 2026 and can be used as a partition column.
- **Reject handling:** the fixtures in `data/tests/` can be used to demonstrate rejection of invalid records. Each defect is listed in `data/tests/README.md`.

## Analytical jobs

- **Totals:** these should filter on `status = 'COMPLETED'`. The dataset also contains 79 `PENDING` and 133 `FAILED` transactions.
- **Customer level:** transactions do not include `customer_id`, so customer-level results require a join through `accounts`.
- **Reference figures** for verifying job output (completed transactions only):

| Check | Count | Total (ETB) |
|---|---|---|
| All completed | 1,788 | 16,822,824.96 |
| 2026-10-01 | 59 | 154,067.73 |
| 2026-10-02 | 52 | 165,374.94 |
| 2026-10-03 | 56 | 148,101.14 |
| BRANCH | 388 | 5,514,779.59 |
| CARD | 257 | 528,903.02 |
| INTERNET | 141 | 4,705,056.30 |
| MOBILE | 676 | 2,001,733.61 |
| USSD | 326 | 4,072,352.44 |

- **Activity:** 238 accounts and 166 customers have at least one transaction.
- **High-value transactions:** 14 transactions are 100,000 ETB or more. This threshold is illustrative and is not a regulatory rule.
- **Timing:** the large dataset (20,000 transactions) is more suitable for timing measurements.

## CDC and streaming

- **Contents:** `cdc_events.jsonl` contains 100 events (68 INSERT, 32 UPDATE), ordered by `event_time` between 06:00 and 06:55 UTC on 1 November 2026.
- **INSERT events** create new transactions from `T00002001` onwards, with `before` set to null.
- **UPDATE events** change a `PENDING` transaction to `COMPLETED` or `FAILED`, with the full previous and new records in `before` and `after`.
- **Ordering:** some UPDATE events refer to transactions created by earlier INSERT events, so events must be processed in order.
- **Deduplication:** keep a record of processed `event_id` values and skip repeats. Log any event older than the last processed event for the same transaction as out of order, rather than applying it.
- **Test fixture:** `data/tests/cdc_events_invalid.jsonl` contains duplicate events, an out-of-order event, a `DELETE` operation, an UPDATE for an unknown transaction and an INSERT that reuses an existing ID.
- **Labelling:** every event carries `"source": "SIMULATED_CDC"`, because the bank does not operate CDC.

## HBase lookup

- **Row keys:** customer identifiers range from `C000001` to `C000200`. They are fixed-width, so they sort correctly as HBase row keys.
- **Consistency:** the customer summary produced by the analytical jobs uses the same identifiers.
- **QA:** `python code/validate_data.py` can be included in the end-to-end QA checklist. It should report `ALL CHECKS PASSED`.

## Architecture

- **File names and counts:** these match the agreed specification.
- **Extra field:** each CDC event includes an additional `source` field. All agreed fields are present.
- **State rules:** only active accounts have transactions, and inactive customers hold only dormant or closed accounts.
- **Limitations relevant to the architecture write-up:**
  - The data is synthetic and far smaller than the bank's.
  - The value distributions are assumed.
  - The region codes are fictional.
  - HR/payroll and digital banking data are not modelled.
  - The CDC feed is simulated.
