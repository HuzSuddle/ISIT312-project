# Generator Instructions

## Requirements

- Python 3.8 or later (tested with 3.11)
- No additional packages are required.

## Running the scripts

Run the following commands from the project folder (the folder containing `code/` and `data/`):

```
python code/generate_synthetic_data.py
python code/validate_data.py --fixtures
python code/make_sample_rows.py
```

1. The first command generates the default dataset in `data/`.
2. The second runs the validation checks and saves the output to `docs/validation_results.txt`.
3. The third refreshes `docs/sample_rows.md`.

A successful validation ends with `ALL CHECKS PASSED`.

## Generating the large dataset

```
python code/generate_synthetic_data.py --size large --out data_large
python code/validate_data.py --data data_large --report docs/validation_results_large.txt
```

The large dataset contains 2,000 customers, 3,000 accounts, 20,000 transactions and 1,000 CDC events. Individual counts can also be set directly, for example `--customers 500 --accounts 800 --transactions 5000 --cdc-events 200`.

## Options

| Option | Default | Description |
|---|---|---|
| `--seed` | 312 | Random seed |
| `--size` | small | Preset size (`small` or `large`) |
| `--start` | 2026-10-01 | First day of the transaction period (UTC) |
| `--days` | 31 | Length of the transaction period |
| `--out` | data | Output folder |
| `--no-fixtures` | off | Skips generation of the test fixtures |

## Reproducibility

All random values are drawn from a single seeded generator, and nothing depends on the system clock. As a result, the same seed and options always produce byte-for-byte identical files. The validation script confirms this by regenerating the data and comparing SHA-256 hashes. `docs/reproducibility_check.txt` records the result of two independent runs.
