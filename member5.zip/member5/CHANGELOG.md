# Changelog

## Version 1.0 (21 November 2026)

- The dataset was regenerated to match the schema agreed for the target architecture.
- Default dataset (seed 312): 200 customers, 300 accounts, 2,000 transactions and 100 CDC events (68 INSERT, 32 UPDATE).
- The validation script runs 68 checks. All of them pass on both the default and the large dataset, and all three test fixtures are rejected.

SHA-256 hashes for this release (also recorded in `data/manifest.json`):

| File | SHA-256 |
|---|---|
| customers.csv | 3e1226e8868fcb5355ee962e2a81764b4390052d500d22f6e8dcd24de1d35585 |
| accounts.csv | b83c04fed37f894278b230f48418b929b93fc3e1782e647b024926bc7928dbf9 |
| transactions.csv | 335a6f8ce363274c37620a756997ebc952de37634ec7e5be8128468f9931cffb |
| cdc_events.jsonl | cee31b68d3b965a5812c306be06cd003f0699d8b3aff1841a2c55a37fa3176a7 |

## Version 0.1 (20 November 2026)

- An initial draft, prepared before the schema was finalised. It used local time, customer names, masked phone numbers and a branch lookup table.
- Replaced in full by version 1.0 and no longer in use.
