# Test fixtures

These files are copies of the normal datasets with known defects added. They are used to confirm that the validation script detects invalid data (`python code/validate_data.py --fixtures`) and should not be loaded as the main dataset.

| File | Record | Defect | Detected by |
|---|---|---|---|
| accounts_invalid.csv | A999901 | Customer C999999 does not exist | Referential integrity |
| accounts_invalid.csv | A000001 | Duplicate account_id | Primary keys |
| accounts_invalid.csv | A999902 | Invalid account_type (GOLD) | Enumerated values |
| accounts_invalid.csv | A999903 | Opened before customer registration | Chronology |
| transactions_invalid.csv | T00000011 | Duplicate transaction_id | Primary keys |
| transactions_invalid.csv | T99999901 | Account A999999 does not exist | Referential integrity |
| transactions_invalid.csv | T99999902 | Invalid status (DONE) | Enumerated values |
| transactions_invalid.csv | T99999903 | Malformed event_ts | Types and formats |
| transactions_invalid.csv | T99999904 | Negative amount | Amounts |
| transactions_invalid.csv | T99999905 | Amount with one decimal place | Types and formats |
| transactions_invalid.csv | T99999906 | txn_date does not match event_ts | Chronology |
| transactions_invalid.csv | T99999907 | Missing amount | Required columns |
| cdc_events_invalid.jsonl | E000021 | Duplicate event | Primary keys |
| cdc_events_invalid.jsonl | E000073 | Duplicate event | Primary keys |
| cdc_events_invalid.jsonl | E000098 | Out-of-order event | Chronology |
| cdc_events_invalid.jsonl | E999901 | Unsupported operation (DELETE) | CDC semantics |
| cdc_events_invalid.jsonl | E999902 | UPDATE for an unknown transaction | CDC semantics |
| cdc_events_invalid.jsonl | E999903 | INSERT reuses an existing ID | CDC semantics |
