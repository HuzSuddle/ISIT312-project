
=========================================================
MEMBER 6 - BATCH INGESTION, CLEANING AND HIVE TABLES
Banking Data Lake Project
=========================================================

1. PROJECT OVERVIEW
-------------------

This component implements the batch data ingestion,
cleaning, validation, curation and Hive querying stages
of the banking data lake.

The implementation uses:
- Apache Hadoop HDFS for distributed storage.
- Python for data cleaning and transformation.
- Apache Hive for SQL-based querying and analysis.
- CSV files as the input and output data format.

2. PROJECT DIRECTORY STRUCTURE
-------------------------------

member6_batch_pipeline/
|
|-- input/
|   |-- customers.csv
|   |-- accounts.csv
|   |-- transactions.csv
|
|-- code/
|   |-- 01_hdfs_load.sh
|   |-- 02_clean_curate.py
|   |-- 03_hive_ddl.hql
|   |-- 04_validation_queries.hql
|
|-- output/
|   |-- cleaned/
|   |-- curated/
|   |-- rejects/
|   |-- row_count_report.csv
|
|-- evidence/
|-- report/

3. SOFTWARE REQUIREMENTS
------------------------

- Ubuntu Linux running inside VirtualBox.
- Java 8.
- Apache Hadoop 2.7.3.
- Apache Hive 2.1.1.
- Python 3.
- Shared folder mounted at /media/sf_vmshare.

4. EXECUTION PROCEDURE
----------------------

STEP 1: START HADOOP

Start HDFS:

/usr/share/hadoop/sbin/start-dfs.sh

Start YARN:

/usr/share/hadoop/sbin/start-yarn.sh

Verify the processes:

jps

STEP 2: PREPARE INPUT DATA

Ensure the following files exist in the input directory:

customers.csv
accounts.csv
transactions.csv

STEP 3: RUN THE PYTHON CLEANING PIPELINE

Execute:

python3 ~/member6_batch_pipeline/code/02_clean_curate.py

The script processes the input datasets, performs
validation, generates cleaned datasets, records rejected
records and produces the curated regulatory daily report.

STEP 4: UPLOAD DATA INTO HDFS

Execute:

bash ~/member6_batch_pipeline/code/01_hdfs_load.sh

This creates the required HDFS directories and uploads
the raw, cleaned, curated and quality datasets.

STEP 5: START HIVE METASTORE

Start the Metastore service:

nohup /usr/share/hive/bin/hive --service metastore \
> ~/member6_batch_pipeline/output/hive-metastore.log 2>&1 &

STEP 6: CREATE HIVE DATABASE AND TABLES

Execute:

/usr/share/hive/bin/hive \
-f ~/member6_batch_pipeline/code/03_hive_ddl.hql

This creates the bank_analytics database and its four
external tables.

STEP 7: RUN VALIDATION AND ANALYTICAL QUERIES

Execute:

/usr/share/hive/bin/hive \
-f ~/member6_batch_pipeline/code/04_validation_queries.hql

This performs record-count checks, sample data retrieval,
relational JOIN operations and analytical queries.

5. EXPECTED DATASET COUNTS
--------------------------

Dataset                  Expected Records
Customers                200
Accounts                 300
Transactions             2,000
Regulatory Daily Report  500

6. HIVE DATABASE TABLES
-----------------------

Database: bank_analytics

Tables:
- bank_customers
- bank_accounts
- bank_transactions
- bank_regulatory_daily

7. HDFS DIRECTORY STRUCTURE
---------------------------

/bank_lake/
    raw/
    cleaned/
    curated/
    quality/

8. IMPLEMENTATION NOTES
-----------------------

The datasets used in this academic implementation are
synthetic and are intended to demonstrate the batch
ingestion and analytical workflow.

The pipeline includes data validation, rejection
handling, row-count reconciliation and generation of
a curated daily regulatory reporting dataset.

Hive external tables provide SQL access to the cleaned
and curated data stored in HDFS.

=========================================================
END OF README
=========================================================
