
#!/bin/bash

# Member 6: Banking Data Lake - HDFS Ingestion
# Creates HDFS directories and uploads raw, cleaned,
# curated and quality datasets.

set -e

export HADOOP_HOME=/usr/share/hadoop
export PATH=$PATH:$HADOOP_HOME/bin:$HADOOP_HOME/sbin

PROJECT="$HOME/member6_batch_pipeline"
INPUT="$PROJECT/input"
OUTPUT="$PROJECT/output"

echo "======================================"
echo " MEMBER 6 - HDFS DATA INGESTION"
echo "======================================"

# 1. Create HDFS directory structure
echo "[1/5] Creating HDFS directories..."

hdfs dfs -mkdir -p /bank_lake/raw
hdfs dfs -mkdir -p /bank_lake/cleaned/customers
hdfs dfs -mkdir -p /bank_lake/cleaned/accounts
hdfs dfs -mkdir -p /bank_lake/cleaned/transactions
hdfs dfs -mkdir -p /bank_lake/curated/regulatory_daily
hdfs dfs -mkdir -p /bank_lake/quality/rejects

# 2. Upload original raw datasets
echo "[2/5] Uploading raw datasets..."

hdfs dfs -put -f "$INPUT/customers.csv" /bank_lake/raw/
hdfs dfs -put -f "$INPUT/accounts.csv" /bank_lake/raw/
hdfs dfs -put -f "$INPUT/transactions.csv" /bank_lake/raw/

# 3. Upload cleaned datasets
echo "[3/5] Uploading cleaned datasets..."

hdfs dfs -put -f "$OUTPUT/cleaned/customers_clean.csv" /bank_lake/cleaned/customers/
hdfs dfs -put -f "$OUTPUT/cleaned/accounts_clean.csv" /bank_lake/cleaned/accounts/
hdfs dfs -put -f "$OUTPUT/cleaned/transactions_clean.csv" /bank_lake/cleaned/transactions/

# 4. Upload curated regulatory report
echo "[4/5] Uploading curated dataset..."

hdfs dfs -put -f "$OUTPUT/curated/bank_regulatory_daily.csv" /bank_lake/curated/regulatory_daily/

# 5. Upload quality reports and rejected records
echo "[5/5] Uploading quality reports..."

hdfs dfs -put -f "$OUTPUT/row_count_report.csv" /bank_lake/quality/

hdfs dfs -put -f "$OUTPUT/rejects/customers_rejects.csv" /bank_lake/quality/rejects/
hdfs dfs -put -f "$OUTPUT/rejects/accounts_rejects.csv" /bank_lake/quality/rejects/
hdfs dfs -put -f "$OUTPUT/rejects/transactions_rejects.csv" /bank_lake/quality/rejects/

echo "======================================"
echo " HDFS INGESTION COMPLETED SUCCESSFULLY"
echo "======================================"

echo "Final HDFS directory structure:"
hdfs dfs -ls -R /bank_lake/
