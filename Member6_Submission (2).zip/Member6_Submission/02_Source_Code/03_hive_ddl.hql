
CREATE DATABASE IF NOT EXISTS bank_analytics;

USE bank_analytics;

CREATE EXTERNAL TABLE IF NOT EXISTS bank_customers (
    customer_id STRING,
    customer_type STRING,
    region_code STRING,
    registration_date DATE,
    status STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/bank_lake/cleaned/customers'
TBLPROPERTIES ('skip.header.line.count'='1');


CREATE EXTERNAL TABLE IF NOT EXISTS bank_accounts (
    account_id STRING,
    customer_id STRING,
    account_type STRING,
    opened_date DATE,
    currency STRING,
    status STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/bank_lake/cleaned/accounts'
TBLPROPERTIES ('skip.header.line.count'='1');


CREATE EXTERNAL TABLE IF NOT EXISTS bank_transactions (
    transaction_id STRING,
    account_id STRING,
    event_ts TIMESTAMP,
    txn_date DATE,
    amount DECIMAL(18,2),
    currency STRING,
    transaction_type STRING,
    channel STRING,
    status STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/bank_lake/cleaned/transactions'
TBLPROPERTIES ('skip.header.line.count'='1');


CREATE EXTERNAL TABLE IF NOT EXISTS bank_regulatory_daily (
    txn_date DATE,
    channel STRING,
    transaction_type STRING,
    status STRING,
    transaction_count INT,
    total_amount_etb DECIMAL(18,2)
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/bank_lake/curated/regulatory_daily'
TBLPROPERTIES ('skip.header.line.count'='1');
