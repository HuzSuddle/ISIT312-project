
-- =====================================================
-- MEMBER 6: BANKING DATA LAKE
-- HIVE VALIDATION AND ANALYTICAL QUERIES
-- Database: bank_analytics
-- =====================================================

USE bank_analytics;


-- -----------------------------------------------------
-- 1. ROW COUNT VALIDATION
-- -----------------------------------------------------

SELECT COUNT(*) AS customer_count
FROM bank_customers;

SELECT COUNT(*) AS account_count
FROM bank_accounts;

SELECT COUNT(*) AS transaction_count
FROM bank_transactions;

SELECT COUNT(*) AS regulatory_report_count
FROM bank_regulatory_daily;


-- -----------------------------------------------------
-- 2. SAMPLE RECORD VALIDATION
-- -----------------------------------------------------

SELECT *
FROM bank_customers
LIMIT 5;

SELECT *
FROM bank_accounts
LIMIT 5;

SELECT *
FROM bank_transactions
LIMIT 5;

SELECT *
FROM bank_regulatory_daily
LIMIT 5;


-- -----------------------------------------------------
-- 3. CUSTOMER AND ACCOUNT JOIN
-- -----------------------------------------------------

SELECT
    c.customer_id,
    c.customer_type,
    a.account_id,
    a.account_type
FROM bank_customers c
JOIN bank_accounts a
    ON c.customer_id = a.customer_id
LIMIT 10;


-- -----------------------------------------------------
-- 4. ACCOUNT AND TRANSACTION JOIN
-- -----------------------------------------------------

SELECT
    a.account_id,
    a.customer_id,
    t.transaction_id,
    t.amount,
    t.currency,
    t.channel
FROM bank_accounts a
JOIN bank_transactions t
    ON a.account_id = t.account_id
LIMIT 10;


-- -----------------------------------------------------
-- 5. CUSTOMER, ACCOUNT AND TRANSACTION JOIN
-- -----------------------------------------------------

SELECT
    c.customer_id,
    a.account_id,
    t.transaction_id,
    t.amount,
    t.transaction_type,
    t.channel
FROM bank_customers c
JOIN bank_accounts a
    ON c.customer_id = a.customer_id
JOIN bank_transactions t
    ON a.account_id = t.account_id
LIMIT 10;


-- -----------------------------------------------------
-- 6. TRANSACTION ANALYSIS BY CHANNEL
-- -----------------------------------------------------

SELECT
    channel,
    COUNT(*) AS transaction_count,
    SUM(amount) AS total_amount
FROM bank_transactions
GROUP BY channel
ORDER BY transaction_count DESC;


-- -----------------------------------------------------
-- 7. TRANSACTION ANALYSIS BY STATUS
-- -----------------------------------------------------

SELECT
    status,
    COUNT(*) AS transaction_count,
    SUM(amount) AS total_amount
FROM bank_transactions
GROUP BY status
ORDER BY transaction_count DESC;


-- -----------------------------------------------------
-- 8. DAILY TRANSACTION SUMMARY
-- -----------------------------------------------------

SELECT
    txn_date,
    COUNT(*) AS transaction_count,
    SUM(amount) AS total_amount
FROM bank_transactions
GROUP BY txn_date
ORDER BY txn_date;


-- -----------------------------------------------------
-- 9. CURATED REGULATORY DAILY REPORT
-- -----------------------------------------------------

SELECT *
FROM bank_regulatory_daily
ORDER BY txn_date
LIMIT 15;


-- =====================================================
-- END OF MEMBER 6 HIVE QUERIES
-- =====================================================
