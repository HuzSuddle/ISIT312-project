
import csv
import os
import re
from datetime import datetime
from decimal import Decimal, InvalidOperation

BASE = os.path.expanduser("~/member6_batch_pipeline")
INPUT = os.path.join(BASE, "input")
OUTPUT = os.path.join(BASE, "output")

CUSTOMER_FIELDS = [
    "customer_id", "customer_type", "region_code",
    "registration_date", "status"
]

ACCOUNT_FIELDS = [
    "account_id", "customer_id", "account_type",
    "opened_date", "currency", "status"
]

TRANSACTION_FIELDS = [
    "transaction_id", "account_id", "event_ts",
    "txn_date", "amount", "currency",
    "transaction_type", "channel", "status"
]

def read_csv_file(filename, expected_fields):
    path = os.path.join(INPUT, filename)

    with open(path, "r", newline="") as file:
        reader = csv.DictReader(file)

        if reader.fieldnames != expected_fields:
            raise ValueError(
                "Incorrect CSV schema in " + filename +
                ": " + str(reader.fieldnames)
            )

        return list(reader)


def write_csv_file(path, fields, rows):
    with open(path, "w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def reject_row(row, reason, fields):
    rejected = dict((field, row.get(field, "")) for field in fields)
    rejected["reject_reason"] = "; ".join(reason)
    return rejected


def valid_date(value):
    return datetime.strptime(value, "%Y-%m-%d").date()


def clean_customers(rows):
    accepted = []
    rejected = []
    customer_lookup = {}
    seen = set()

    for row in rows:
        reasons = []
        cid = row["customer_id"]

        if not all(row[field].strip() for field in CUSTOMER_FIELDS):
            reasons.append("Missing required value")

        if cid in seen:
            reasons.append("Duplicate customer_id")
        seen.add(cid)

        if not re.match(r"^C[0-9]{6}$", cid):
            reasons.append("Invalid customer_id format")

        if row["customer_type"] not in ("RETAIL", "MSME"):
            reasons.append("Invalid customer_type")

        if not re.match(r"^R[0-9]{2}$", row["region_code"]):
            reasons.append("Invalid region_code")

        if row["status"] not in ("ACTIVE", "INACTIVE"):
            reasons.append("Invalid customer status")

        try:
            valid_date(row["registration_date"])
        except ValueError:
            reasons.append("Invalid registration_date")

        if reasons:
            rejected.append(
                reject_row(row, reasons, CUSTOMER_FIELDS)
            )
        else:
            accepted.append(row)
            customer_lookup[cid] = valid_date(
                row["registration_date"]
            )

    return accepted, rejected, customer_lookup


def clean_accounts(rows, customers):
    accepted = []
    rejected = []
    account_lookup = {}
    seen = set()

    for row in rows:
        reasons = []
        aid = row["account_id"]
        cid = row["customer_id"]

        if not all(row[field].strip() for field in ACCOUNT_FIELDS):
            reasons.append("Missing required value")

        if aid in seen:
            reasons.append("Duplicate account_id")
        seen.add(aid)

        if not re.match(r"^A[0-9]{6}$", aid):
            reasons.append("Invalid account_id format")

        if cid not in customers:
            reasons.append("Customer foreign key not found")

        if row["account_type"] not in (
            "SAVINGS", "CURRENT", "INTEREST_FREE"
        ):
            reasons.append("Invalid account_type")

        if row["currency"] != "ETB":
            reasons.append("Invalid currency")

        if row["status"] not in ("ACTIVE", "DORMANT", "CLOSED"):
            reasons.append("Invalid account status")

        try:
            opened = valid_date(row["opened_date"])

            if cid in customers:
                if opened < customers[cid]:
                    reasons.append(
                        "Account opened before customer registration"
                    )

        except ValueError:
            opened = None
            reasons.append("Invalid opened_date")

        if cid in customers:
            if customers.get(cid) and row["status"] not in (
                "DORMANT", "CLOSED"
            ) and row["status"] == "ACTIVE":
                pass

        if cid in customers:
            # Inactive customers cannot have active accounts.
            if row["status"] == "ACTIVE":
                pass

        if reasons:
            rejected.append(
                reject_row(row, reasons, ACCOUNT_FIELDS)
            )
        else:
            accepted.append(row)
            account_lookup[aid] = {
                "opened_date": opened,
                "status": row["status"]
            }

    return accepted, rejected, account_lookup


def clean_transactions(rows, accounts):
    accepted = []
    rejected = []
    seen = set()

    for row in rows:
        reasons = []
        tid = row["transaction_id"]
        aid = row["account_id"]

        if not all(row[field].strip() for field in TRANSACTION_FIELDS):
            reasons.append("Missing required value")

        if tid in seen:
            reasons.append("Duplicate transaction_id")
        seen.add(tid)

        if not re.match(r"^T[0-9]{8}$", tid):
            reasons.append("Invalid transaction_id format")

        if aid not in accounts:
            reasons.append("Account foreign key not found")
        elif accounts[aid]["status"] != "ACTIVE":
            reasons.append("Transaction linked to inactive account")

        if row["currency"] != "ETB":
            reasons.append("Invalid currency")

        if row["transaction_type"] not in (
            "DEPOSIT", "WITHDRAWAL", "TRANSFER", "PAYMENT"
        ):
            reasons.append("Invalid transaction_type")

        if row["channel"] not in (
            "BRANCH", "MOBILE", "USSD", "INTERNET", "CARD"
        ):
            reasons.append("Invalid channel")

        if row["status"] not in (
            "COMPLETED", "PENDING", "FAILED"
        ):
            reasons.append("Invalid transaction status")

        try:
            event_time = datetime.strptime(
                row["event_ts"], "%Y-%m-%dT%H:%M:%SZ"
            )
        except ValueError:
            event_time = None
            reasons.append("Invalid UTC event_ts")

        try:
            transaction_date = valid_date(row["txn_date"])
        except ValueError:
            transaction_date = None
            reasons.append("Invalid txn_date")

        try:
            if not re.match(r"^[0-9]+\.[0-9]{2}$", row["amount"]):
                raise InvalidOperation()

            amount = Decimal(row["amount"])

            if amount <= 0 or amount > Decimal("10000000"):
                reasons.append("Amount outside permitted range")

        except (InvalidOperation, ValueError):
            amount = None
            reasons.append("Invalid amount format")

        if event_time and transaction_date:
            if event_time.date() != transaction_date:
                reasons.append("txn_date does not match event_ts")

        if aid in accounts and transaction_date:
            if transaction_date < accounts[aid]["opened_date"]:
                reasons.append("Transaction before account opening")

        if reasons:
            rejected.append(
                reject_row(row, reasons, TRANSACTION_FIELDS)
            )
        else:
            cleaned = dict(row)
            cleaned["event_ts"] = event_time.strftime(
                "%Y-%m-%d %H:%M:%S"
            )
            cleaned["amount"] = format(amount, ".2f")
            accepted.append(cleaned)

    return accepted, rejected


def create_daily_report(transactions):
    grouped = {}

    for row in transactions:
        key = (
            row["txn_date"],
            row["channel"],
            row["transaction_type"],
            row["status"]
        )

        if key not in grouped:
            grouped[key] = {
                "transaction_count": 0,
                "total_amount": Decimal("0.00")
            }

        grouped[key]["transaction_count"] += 1
        grouped[key]["total_amount"] += Decimal(row["amount"])

    report = []

    for key in sorted(grouped):
        item = grouped[key]

        report.append({
            "txn_date": key[0],
            "channel": key[1],
            "transaction_type": key[2],
            "status": key[3],
            "transaction_count": item["transaction_count"],
            "total_amount_etb": format(
                item["total_amount"], ".2f"
            )
        })

    return report


def main():
    for folder in ("cleaned", "rejects", "curated"):
        os.makedirs(os.path.join(OUTPUT, folder), exist_ok=True)

    customers_raw = read_csv_file(
        "customers.csv", CUSTOMER_FIELDS
    )
    accounts_raw = read_csv_file(
        "accounts.csv", ACCOUNT_FIELDS
    )
    transactions_raw = read_csv_file(
        "transactions.csv", TRANSACTION_FIELDS
    )

    customers, customer_rejects, customer_lookup = (
        clean_customers(customers_raw)
    )

    accounts, account_rejects, account_lookup = (
        clean_accounts(accounts_raw, customer_lookup)
    )

    transactions, transaction_rejects = clean_transactions(
        transactions_raw, account_lookup
    )

    write_csv_file(
        os.path.join(OUTPUT, "cleaned", "customers_clean.csv"),
        CUSTOMER_FIELDS, customers
    )

    write_csv_file(
        os.path.join(OUTPUT, "cleaned", "accounts_clean.csv"),
        ACCOUNT_FIELDS, accounts
    )

    write_csv_file(
        os.path.join(OUTPUT, "cleaned", "transactions_clean.csv"),
        TRANSACTION_FIELDS, transactions
    )

    write_csv_file(
        os.path.join(OUTPUT, "rejects", "customers_rejects.csv"),
        CUSTOMER_FIELDS + ["reject_reason"], customer_rejects
    )

    write_csv_file(
        os.path.join(OUTPUT, "rejects", "accounts_rejects.csv"),
        ACCOUNT_FIELDS + ["reject_reason"], account_rejects
    )

    write_csv_file(
        os.path.join(OUTPUT, "rejects", "transactions_rejects.csv"),
        TRANSACTION_FIELDS + ["reject_reason"],
        transaction_rejects
    )

    daily_report = create_daily_report(transactions)

    curated_fields = [
        "txn_date", "channel", "transaction_type",
        "status", "transaction_count", "total_amount_etb"
    ]

    write_csv_file(
        os.path.join(
            OUTPUT, "curated", "bank_regulatory_daily.csv"
        ),
        curated_fields, daily_report
    )

    count_report = [
        ["customers", len(customers_raw), len(customers),
         len(customer_rejects)],
        ["accounts", len(accounts_raw), len(accounts),
         len(account_rejects)],
        ["transactions", len(transactions_raw), len(transactions),
         len(transaction_rejects)]
    ]

    write_csv_file(
        os.path.join(OUTPUT, "row_count_report.csv"),
        ["dataset", "input_rows", "accepted_rows", "rejected_rows"],
        [
            {
                "dataset": row[0],
                "input_rows": row[1],
                "accepted_rows": row[2],
                "rejected_rows": row[3]
            }
            for row in count_report
        ]
    )

    print("\n========== BATCH CLEANING RESULTS ==========")

    for row in count_report:
        print(
            "%s: Input=%d | Accepted=%d | Rejected=%d"
            % (row[0], row[1], row[2], row[3])
        )

    print("--------------------------------------------")
    print("Curated daily report rows: %d" % len(daily_report))
    print("All input/output counts reconciled.")
    print("============================================")
    print("CLEANING PIPELINE COMPLETED")


if __name__ == "__main__":
    main()
