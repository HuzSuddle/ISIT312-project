#HBase lookup, end-to-end integration tests and slide assembly

## Files in the package
| Item | Path 
|---|---
| End-to-end QA checklist + defect log | 'end_to_end_qa_checklist.xlsx'
| HBase scripts | 'code/' 
| Source CSV | 'input/customer_summary_for_hbase.csv'
| Screenshots | 'evidence/screenshots/'

## Order of work
1. Copy this folder to the VM ('/Member9_submission'), remove Windows line endings
2. Start Hadoop/YARN/Hive metastore, then inspect HBase, then start HBase
3. 'bash code/07a_hbase_load.sh'-> 'hbase shell -n code/07_hbase_lookup.txt' -> '07b_verify_hbase.py' -> 'bash code/07d_qa_checks.sh'
4. Fill the xlsx, the docx, the lessons file. Push to GitHub from your normal computer.

## Status labels
- Implemented & tested
- Simulated & tested
- Designed only
- Blocked
