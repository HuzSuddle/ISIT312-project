#Create the HBase table and load the 200-row customer summary.
# Safe to re-run: an existing bank_customer_summary table is dropped and rebuilt (the source CSV is never changed)

cd "$(dirname "$0")/.." || exit 1
source code/00_hbase_env.sh || exit 1

TABLE=bank_customer_summary
CSV=input/customer_summary_for_hbase.csv
LOG=results/hbase_load_log.txt
HB="$HBASE_HOME/bin/hbase"
mkdir -p results
echo "=== HBase load started $(date '+%F %T')" | tee "$LOG"

echo "[1/6] Generate put commands" | tee -a "$LOG"
python3 code/07a_generate_puts.py --csv "$CSV" --out results/load_puts.hbase 2>&1 | tee -a "$LOG"

echo "[2/6] Drop old table if it exists" | tee -a "$LOG"
if echo "list" | "$HB" shell 2>/dev/null | grep -q "$TABLE"; then
  printf "disable '%s'\ndrop '%s'\n" "$TABLE" "$TABLE" | "$HB" shell 2>&1 | tail -n 6 | tee -a "$LOG"
else
  echo "table not present - nothing to drop" | tee -a "$LOG"
fi

echo "[3/6] Create table with column families profile and metrics" | tee -a "$LOG"
echo "create '$TABLE', 'profile', 'metrics'" | "$HB" shell 2>&1 | tail -n 6 | tee -a "$LOG"

echo "[4/6] Load data (about 2,932 puts)" | tee -a "$LOG"
START=$(date +%s)
"$HB" shell -n results/load_puts.hbase 2>&1 | tail -n 5 | tee -a "$LOG"
END=$(date +%s)
echo "load wall time: $((END-START)) s" | tee -a "$LOG"

echo "[5/6] Row count" | tee -a "$LOG"
echo "count '$TABLE'" > results/count_cmd.hbase
"$HB" shell -n results/count_cmd.hbase 2>&1 | tail -n 4 | tee -a "$LOG"

echo "[6/6] Full scan dump for the verifier" | tee -a "$LOG"
echo "scan '$TABLE'" > results/full_scan_cmd.hbase
"$HB" shell -n results/full_scan_cmd.hbase > results/hbase_full_scan.txt 2>&1
echo "scan lines written: $(grep -c 'column=' results/hbase_full_scan.txt)  (expected 2932)" | tee -a "$LOG"

echo "=== HBase load finished $(date '+%F %T')" | tee -a "$LOG"
