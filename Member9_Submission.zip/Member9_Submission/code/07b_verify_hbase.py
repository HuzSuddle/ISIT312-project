# Verify HBase contents against the source CSV.

#   Full verification (all 200 rows) from the scan dump:
#     python3 code/07b_verify_hbase.py --scan results/hbase_full_scan.txt \
#         --csv input/customer_summary_for_hbase.csv

#   Spot checks from the lookup script output:
#     python3 code/07b_verify_hbase.py --get results/hbase_get_outputs.txt \
#         --csv input/customer_summary_for_hbase.csv

#   Both at once (recommended):
#     python3 code/07b_verify_hbase.py --scan results/hbase_full_scan.txt \
#         --get results/hbase_get_outputs.txt --csv input/customer_summary_for_hbase.csv \
#         | tee results/hbase_verification.txt
#
# Reads only text files that you produced with the HBase shell; it never
# contacts HBase itself and never writes anything. Exit code 0 = all PASS.

#   completed transactions 1,788 | completed value 16,822,824.96 ETB |
#   transacting customers 166 | high-value transactions (>=100,000 ETB) 14

import argparse
import csv
import re
import sys
from decimal import Decimal, InvalidOperation

# (csv column, hbase family, hbase qualifier) - keep identical to 07a_generate_puts.py
COLUMN_MAP = [
    ('customer_type',        'profile', 'customer_type'),
    ('region_code',          'profile', 'region_code'),
    ('customer_status',      'profile', 'status'),
    ('registration_date',    'profile', 'registration_date'),
    ('num_accounts',         'metrics', 'num_accounts'),
    ('num_active_accounts',  'metrics', 'num_active_accounts'),
    ('txn_count_all',        'metrics', 'txn_count_all'),
    ('completed_txn_count',  'metrics', 'completed_txn_count'),
    ('pending_txn_count',    'metrics', 'pending_txn_count'),
    ('failed_txn_count',     'metrics', 'failed_txn_count'),
    ('completed_value_etb',  'metrics', 'completed_value_etb'),
    ('avg_completed_etb',    'metrics', 'avg_completed_etb'),
    ('high_value_txn_count', 'metrics', 'high_value_txn_count'),
    ('first_txn_date',       'metrics', 'first_txn_date'),
    ('last_txn_date',        'metrics', 'last_txn_date'),
]

SCAN_RE = re.compile(r'^\s*(\S+)\s+column=([A-Za-z_]+:[A-Za-z_]+),\s*timestamp=(\d+),\s*value=(.*?)\s*$')
GET_RE = re.compile(r'^\s*([A-Za-z_]+:[A-Za-z_]+)\s+timestamp=(\d+),\s*value=(.*?)\s*$')
MARK_RE = re.compile(r'^### GET (\S+)\s*$')
OTHER_MARK_RE = re.compile(r'^###')

RESULTS = []


def check(name, ok, detail=''):
    RESULTS.append(bool(ok))
    line = '[{0}] {1}'.format('PASS' if ok else 'FAIL', name)
    if detail:
        line += '  - ' + detail
    print(line)


def values_equal(a, b):
    if a == b:
        return True
    try:
        return Decimal(a) == Decimal(b)
    except (InvalidOperation, ValueError):
        return False


def load_csv(path):
    rows = {}
    with open(path, 'r', newline='') as f:
        for r in csv.DictReader(f):
            rows[r['customer_id']] = r
    return rows


def expected_cells(csv_row):
    cells = {}
    for csv_col, family, qualifier in COLUMN_MAP:
        v = csv_row[csv_col]
        if v != '':
            cells[family + ':' + qualifier] = v
    return cells


def parse_scan(path):
    data = {}
    with open(path, 'r', errors='replace') as f:
        for line in f:
            m = SCAN_RE.match(line)
            if m:
                data.setdefault(m.group(1), {})[m.group(2)] = m.group(4)
    return data


def parse_get_sections(path):
    sections = {}
    current = None
    with open(path, 'r', errors='replace') as f:
        for line in f:
            line = line.rstrip('\n')
            m = MARK_RE.match(line)
            if m:
                current = m.group(1)
                sections[current] = {}
                continue
            if OTHER_MARK_RE.match(line):
                current = None
                continue
            if current is not None:
                g = GET_RE.match(line)
                if g:
                    sections[current][g.group(1)] = g.group(3)
    return sections


def verify_scan(scan_path, csv_rows, args):
    print('--- Full verification from scan dump: {0}'.format(scan_path))
    data = parse_scan(scan_path)

    missing = sorted(set(csv_rows) - set(data))
    extra = sorted(set(data) - set(csv_rows))
    check('row keys match the CSV ({0} expected)'.format(len(csv_rows)),
          not missing and not extra and len(data) == len(csv_rows),
          'HBase rows={0}, missing={1}, extra={2}'.format(len(data), len(missing), len(extra)))

    exp_total = sum(len(expected_cells(r)) for r in csv_rows.values())
    got_total = sum(len(c) for c in data.values())
    check('total non-empty cells match ({0} expected)'.format(exp_total), exp_total == got_total,
          'HBase cells={0}'.format(got_total))

    mismatches = []
    unexpected_cells = []
    for key, r in csv_rows.items():
        exp = expected_cells(r)
        got = data.get(key, {})
        for col, val in exp.items():
            if col not in got:
                mismatches.append('{0} {1}: missing (expected {2})'.format(key, col, val))
            elif not values_equal(got[col], val):
                mismatches.append('{0} {1}: HBase={2} CSV={3}'.format(key, col, got[col], val))
        for col in got:
            if col not in exp:
                unexpected_cells.append('{0} {1}={2}'.format(key, col, got[col]))
    check('every non-empty CSV value equals the HBase value', not mismatches,
          '{0} mismatches'.format(len(mismatches)))
    for m in mismatches[:10]:
        print('        ' + m)
    empty_expected = sum(1 for r in csv_rows.values() for c in COLUMN_MAP if r[c[0]] == '')
    check('empty CSV values are absent in HBase ({0} expected absent)'.format(empty_expected),
          not unexpected_cells, '{0} unexpected cells'.format(len(unexpected_cells)))
    for m in unexpected_cells[:10]:
        print('        ' + m)

    def num(key, col):
        v = data[key].get(col)
        return Decimal(v) if v not in (None, '') else Decimal(0)

    keys = list(data)
    s_completed = sum(num(k, 'metrics:completed_txn_count') for k in keys)
    s_value = sum(num(k, 'metrics:completed_value_etb') for k in keys)
    s_transacting = sum(1 for k in keys if num(k, 'metrics:txn_count_all') > 0)
    s_highvalue = sum(num(k, 'metrics:high_value_txn_count') for k in keys)
    check('sum of completed transactions = {0}'.format(args.expected_completed),
          s_completed == Decimal(args.expected_completed), 'HBase total={0}'.format(s_completed))
    check('sum of completed value = {0} ETB'.format(args.expected_value),
          s_value == Decimal(args.expected_value), 'HBase total={0}'.format(s_value))
    check('transacting customers = {0}'.format(args.expected_transacting),
          s_transacting == int(args.expected_transacting), 'HBase count={0}'.format(s_transacting))
    check('high-value transactions = {0}'.format(args.expected_highvalue),
          s_highvalue == Decimal(args.expected_highvalue), 'HBase total={0}'.format(s_highvalue))


def verify_get(get_path, csv_rows, spot_ids):
    print('--- Spot checks from lookup output: {0}'.format(get_path))
    sections = parse_get_sections(get_path)
    for cid in spot_ids:
        if cid not in sections:
            check('GET {0} section present'.format(cid), False, 'marker not found in file')
            continue
        exp = expected_cells(csv_rows[cid])
        got = sections[cid]
        bad = []
        for col, val in exp.items():
            if col not in got:
                bad.append('{0} missing'.format(col))
            elif not values_equal(got[col], val):
                bad.append('{0}: HBase={1} CSV={2}'.format(col, got[col], val))
        extra = [c for c in got if c not in exp]
        check('GET {0}: all {1} cells match the CSV'.format(cid, len(exp)),
              not bad and not extra and len(got) == len(exp),
              'cells returned={0}'.format(len(got)))
        for b in bad[:10]:
            print('        ' + b)
        for c in extra[:10]:
            print('        unexpected cell ' + c)
        print('        completed_txn_count={0}  completed_value_etb={1}  high_value_txn_count={2}'.format(
            got.get('metrics:completed_txn_count'), got.get('metrics:completed_value_etb'),
            got.get('metrics:high_value_txn_count')))
    if 'C999999' in sections:
        check('GET C999999 (missing key) returns no cells', len(sections['C999999']) == 0,
              'cells returned={0}'.format(len(sections['C999999'])))
    else:
        check('GET C999999 section present', False, 'marker not found in file')


def main():
    ap = argparse.ArgumentParser(description='Verify HBase output against the source CSV')
    ap.add_argument('--csv', default='input/customer_summary_for_hbase.csv')
    ap.add_argument('--scan', help='file produced by: scan \'bank_customer_summary\'')
    ap.add_argument('--get', help='file produced by hbase shell -n code/07_hbase_lookup.txt')
    ap.add_argument('--spot', default='C000001,C000044,C000188', help='comma-separated spot-check customer IDs')
    ap.add_argument('--expected-completed', default='1788')
    ap.add_argument('--expected-value', default='16822824.96')
    ap.add_argument('--expected-transacting', default='166')
    ap.add_argument('--expected-highvalue', default='14')
    args = ap.parse_args()

    if not args.scan and not args.get:
        print('ERROR: give --scan and/or --get')
        sys.exit(2)

    csv_rows = load_csv(args.csv)
    print('Source CSV: {0} ({1} customers)'.format(args.csv, len(csv_rows)))
    if args.scan:
        verify_scan(args.scan, csv_rows, args)
    if args.get:
        verify_get(args.get, csv_rows, [s.strip() for s in args.spot.split(',') if s.strip()])

    passed = sum(1 for r in RESULTS if r)
    print('')
    print('SUMMARY: {0} of {1} checks passed'.format(passed, len(RESULTS)))
    if RESULTS and passed == len(RESULTS):
        print('OVERALL: PASS - HBase contents match the source CSV')
        sys.exit(0)
    print('OVERALL: FAIL - see the FAIL lines above')
    sys.exit(1)


if __name__ == '__main__':
    main()
