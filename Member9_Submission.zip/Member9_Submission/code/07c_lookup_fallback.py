#!/usr/bin/env python3
# =====================================================================
# MEMBER 9 - FALLBACK ONLY: labelled lookup SIMULATION (this is NOT HBase)
# Python 3.4 compatible, standard library only.
#
# Use this ONLY if HBase cannot be started on the VM. In the report and slides
# the result must be described as "Simulated lookup (not HBase)" together with
# the documented HBase design (table, row key, column families). Never show its
# output as an HBase run.
#
#   python3 code/07c_lookup_fallback.py --get C000188
#   python3 code/07c_lookup_fallback.py --get C000001 --get C000044 --get C999999
#   python3 code/07c_lookup_fallback.py --range C000001 C000004
# =====================================================================
import argparse
import csv
import time

COLUMN_MAP = [
    ('customer_type',        'profile', 'customer_type'),
    ('region_code',          'profile', 'region_code'),
    ('customer_status',      'profile', 'status'),
    ('registration_date',    'profile', 'registration_date'),
    ('num_accounts',         'metrics', 'num_accounts'),
    ('num_active_accounts',  'metrics', 'num_active_accounts'),
    ('txn_count_all',        'metrics', 'txn_count_all'),
    ('completed_txn_count',  'metrics', 'completed_txn_count'),
    ('pending_txn_count',    'metrics', 'pending_txn_count'),
    ('failed_txn_count',     'metrics', 'failed_txn_count'),
    ('completed_value_etb',  'metrics', 'completed_value_etb'),
    ('avg_completed_etb',    'metrics', 'avg_completed_etb'),
    ('high_value_txn_count', 'metrics', 'high_value_txn_count'),
    ('first_txn_date',       'metrics', 'first_txn_date'),
    ('last_txn_date',        'metrics', 'last_txn_date'),
]

BANNER = [
    '*' * 72,
    '* SIMULATION ONLY - THIS IS NOT HBASE.',
    '* A Python dictionary built from the CSV is being queried by key.',
    '* Timings below are NOT HBase measurements.',
    '*' * 72,
]


def show(key, row):
    print('ROW {0}'.format(key))
    if row is None:
        print('  (no such key - 0 cells returned)')
        return
    for csv_col, family, qualifier in COLUMN_MAP:
        if row[csv_col] != '':
            print('  {0}:{1} = {2}'.format(family, qualifier, row[csv_col]))


def main():
    ap = argparse.ArgumentParser(description='Lookup simulation (not HBase)')
    ap.add_argument('--csv', default='input/customer_summary_for_hbase.csv')
    ap.add_argument('--get', action='append', default=[])
    ap.add_argument('--range', nargs=2, metavar=('START', 'STOP'))
    args = ap.parse_args()

    for line in BANNER:
        print(line)
    index = {}
    with open(args.csv, 'r', newline='') as f:
        for r in csv.DictReader(f):
            index[r['customer_id']] = r
    print('loaded {0} customers into an in-memory dictionary'.format(len(index)))

    for key in args.get:
        t0 = time.time()
        row = index.get(key)
        elapsed = (time.time() - t0) * 1000.0
        show(key, row)
        print('  [simulated lookup took {0:.4f} ms - not an HBase timing]'.format(elapsed))

    if args.range:
        start, stop = args.range
        for key in sorted(index):
            if start <= key < stop:
                show(key, index[key])
        print('  [range semantics copied from HBase: start inclusive, stop exclusive]')

    for line in BANNER[:1]:
        print(line)


if __name__ == '__main__':
    main()
