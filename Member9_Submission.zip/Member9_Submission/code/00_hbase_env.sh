# HBase environment (source this file, do not execute it)
#   usage:  source code/00_hbase_env.sh
# Uses a PRIVATE copy of the HBase configuration, logs and data inside
# is needed. HBase runs in standalone mode 


export HBASE_HOME=${HBASE_HOME:-/usr/share/hbase-1.2.6}
export M9_HOME=${M9_HOME:-$HOME/member9_hbase_qa}

if [ -z "$JAVA_HOME" ]; then
  export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java))))
fi

export HBASE_CONF_DIR=$M9_HOME/hbase_conf
export HBASE_LOG_DIR=$M9_HOME/hbase_logs
export HBASE_PID_DIR=$M9_HOME/hbase_pids
export PATH=$HBASE_HOME/bin:$PATH
mkdir -p "$HBASE_LOG_DIR" "$HBASE_PID_DIR" "$M9_HOME/hbase_data" "$M9_HOME/zookeeper_data" "$M9_HOME/results"

if [ ! -x "$HBASE_HOME/bin/hbase" ]; then
  echo "ERROR: $HBASE_HOME/bin/hbase not found. Set HBASE_HOME to the HBase folder under /usr/share."
  return 1 2>/dev/null || exit 1
fi

if [ ! -d "$HBASE_CONF_DIR" ]; then
  cp -r "$HBASE_HOME/conf" "$HBASE_CONF_DIR"
  echo "--- ORIGINAL $HBASE_HOME/conf/hbase-site.xml (kept for the record) ---"
  cat "$HBASE_HOME/conf/hbase-site.xml"
  echo "--- end of original ---"
  cat > "$HBASE_CONF_DIR/hbase-site.xml" <<XML
<?xml version="1.0"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
  <property>
    <name>hbase.rootdir</name>
    <value>file://$M9_HOME/hbase_data/hbase</value>
  </property>
  <property>
    <name>hbase.zookeeper.property.dataDir</name>
    <value>$M9_HOME/zookeeper_data</value>
  </property>
</configuration>
XML
  echo "Created private standalone config in $HBASE_CONF_DIR"
fi

echo "HBASE_HOME     = $HBASE_HOME"
echo "JAVA_HOME      = $JAVA_HOME"
echo "HBASE_CONF_DIR = $HBASE_CONF_DIR"
