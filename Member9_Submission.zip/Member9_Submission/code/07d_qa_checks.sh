cd "$(dirname "$0")/.." || exit 1
LOG=results/qa_run_log.txt
mkdir -p results
export HADOOP_HOME=${HADOOP_HOME:-/usr/share/hadoop}
export HIVE_HOME=${HIVE_HOME:-/usr/share/hive}
export PATH=$PATH:$HADOOP_HOME/bin:$HIVE_HOME/bin

section() { echo "" | tee -a "$LOG"; echo "=== $1   [$(date '+%F %T')]" | tee -a "$LOG"; }
run()     { echo "\$ $*" | tee -a "$LOG"; bash -c "$*" 2>&1 | tee -a "$LOG"; }

echo "QA quick checks started $(date '+%F %T') by $(whoami) on $(hostname)" | tee "$LOG"

section "1. Versions and services  (checklist E1-E6)"
run "hadoop version | head -1"
run "hive --version 2>/dev/null | head -2"
run "python3 --version"
run "ls -d /usr/share/spark* 2>/dev/null || echo 'no /usr/share/spark* folder found'"
run "ls /usr/share | grep -i -E 'kafka|hbase|spark' || true"
run "jps"

section "2. HDFS zones  (checklist H1-H4)"
run "hdfs dfs -ls -R /bank_lake"

section "3. Row counts straight from HDFS files (header removed)  (checklist D1, H5)"
for P in "raw/customers.csv" "raw/accounts.csv" "raw/transactions.csv" \
         "cleaned/customers/*" "cleaned/accounts/*" "cleaned/transactions/*" \
         "curated/regulatory_daily/*" "curated/hbase_feed/*"; do
  echo "\$ hdfs dfs -cat /bank_lake/$P | tail -n +2 | wc -l" | tee -a "$LOG"
  echo "   $P -> $(hdfs dfs -cat /bank_lake/$P 2>/dev/null | tail -n +2 | wc -l) rows" | tee -a "$LOG"
done
echo "(expected: customers 200, accounts 300, transactions 2000, regulatory_daily 500, hbase_feed 200)" | tee -a "$LOG"

section "4. Raw zone unchanged versus Member 6 input  (checklist H5)"
if [ -d "$HOME/member6_batch_pipeline/input" ]; then
  for F in customers accounts transactions; do
    A=$(hdfs dfs -cat /bank_lake/raw/$F.csv 2>/dev/null | md5sum | cut -d' ' -f1)
    B=$(md5sum "$HOME/member6_batch_pipeline/input/$F.csv" 2>/dev/null | cut -d' ' -f1)
    if [ -n "$A" ] && [ "$A" = "$B" ]; then echo "   $F.csv : raw copy identical to input (md5 $A)" | tee -a "$LOG";
    else echo "   $F.csv : DIFFERENT or missing (hdfs $A / local $B)" | tee -a "$LOG"; fi
  done
else
  echo "   ~/member6_batch_pipeline/input not found - skipped (mark H5 'Not run')" | tee -a "$LOG"
fi

section "5. Hive tables and counts  (checklist V1-V4)  - takes several minutes"
run "hive -S -e \"USE bank_analytics; SHOW TABLES; SELECT 'bank_customers', COUNT(*) FROM bank_customers; SELECT 'bank_accounts', COUNT(*) FROM bank_accounts; SELECT 'bank_transactions', COUNT(*) FROM bank_transactions; SELECT 'bank_regulatory_daily', COUNT(*) FROM bank_regulatory_daily; SELECT 'bank_customer_summary', COUNT(*) FROM bank_customer_summary;\""
echo "(expected: 200 / 300 / 2000 / 500 / 200)" | tee -a "$LOG"

section "6. HBase table  (checklist B1-B3)"
if [ -f code/00_hbase_env.sh ]; then
  source code/00_hbase_env.sh >/dev/null 2>&1
  printf "status\nlist\ncount 'bank_customer_summary'\n" | hbase shell 2>&1 | grep -v '^$' | tail -n 15 | tee -a "$LOG"
fi

section "7. Where does CDC output live?  (checklist C5)"
run "hdfs dfs -ls /bank_lake/raw"
echo "   (Member 4's contract expected /bank_lake/raw/cdc/ ; Member 8's outputs are on the local VM disk.)" | tee -a "$LOG"
for D in "$HOME/member8_cdc_streaming/output/processed" "$HOME/member8_cdc_streaming/output/live_results/processed"; do
  if [ -d "$D" ]; then echo "   found local CDC output folder: $D" | tee -a "$LOG"; fi
done

echo "" | tee -a "$LOG"
echo "QA quick checks finished $(date '+%F %T')" | tee -a "$LOG"
echo "Now open end_to_end_qa_checklist.xlsx and record Pass / Fail per row, using $LOG as evidence." | tee -a "$LOG"
