# Handoff to Member 9 – customer summary for HBase

**File:** `results/customer_summary_for_hbase.csv` (re-exported on the VM as `customer_summary_for_hbase_vm.csv` and in HDFS at `/bank_lake/curated/hbase_feed/customer_summary_for_hbase.csv`)

* **Rows:** 200, one per customer (`C000001` to `C000200`), with a header row. Customers without transactions are included with zero metrics and empty first/last dates.
* **Source:** the Hive table `bank_analytics.bank_customer_summary`, built by Job 2 (`code/04b_job2_customer_summary.hql`).
* **Validated:** the exported file matches the expected output, and its totals reconcile with Member 5's reference figures: 300 accounts, 166 transacting customers, 1,788 completed transactions and 16,822,824.96 ETB.

## Proposed HBase mapping (table `bank_customer_summary`, per the team contract)

| CSV column | HBase | Notes |
|---|---|---|
| customer_id | **row key** | fixed-width, so it sorts correctly |
| customer_type | profile:customer_type | RETAIL / MSME |
| region_code | profile:region_code | synthetic R01–R12 |
| customer_status | profile:status | ACTIVE / INACTIVE |
| registration_date | profile:registration_date | YYYY-MM-DD |
| num_accounts | metrics:num_accounts | |
| num_active_accounts | metrics:num_active_accounts | |
| txn_count_all | metrics:txn_count_all | all statuses, Oct 2026 |
| completed_txn_count | metrics:completed_txn_count | |
| pending_txn_count | metrics:pending_txn_count | |
| failed_txn_count | metrics:failed_txn_count | |
| completed_value_etb | metrics:completed_value_etb | ETB, 2 decimals |
| avg_completed_etb | metrics:avg_completed_etb | 0.00 if no completed txns |
| high_value_txn_count | metrics:high_value_txn_count | amount >= 100,000 ETB (illustrative) |
| first_txn_date | metrics:first_txn_date | empty if none |
| last_txn_date | metrics:last_txn_date | empty if none |

## Spot-check values for your `get` test (small dataset)

Run the following and compare the output with the HBase `get` result:

```
grep -E "^(C000001|C000044|C000188)," results/customer_summary_for_hbase.csv
```

C000188 holds the largest single transaction (T00001243, 1,868,879.06 ETB, INTERNET transfer), so its `high_value_txn_count` is at least 1.

Note: the Hive export prints numbers without trailing zeros (e.g. `0` instead of `0.00`). The values are the same.
