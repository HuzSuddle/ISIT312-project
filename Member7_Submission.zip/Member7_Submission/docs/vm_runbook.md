# Member 7 – Analytical Jobs, Reporting Use Cases and Measurements

Banking data lake prototype (ISIT312). All data is synthetic (Member 5); the jobs run on Member 6's Hive tables in `bank_analytics`.

## Status (evidence labels)

| Item | Status |
|---|---|
| Job SQL (3 jobs, 9 result sets) | Written for Hive 2.1.1. Runs unchanged in Spark SQL (tested on Spark 4.1 outside the VM) |
| Expected outputs | Computed two independent ways (plain Python and Spark SQL), and both give the same results. They also match Member 5's reference figures |
| `customer_summary_for_hbase.csv` | Ready (200 rows). Re-export on the VM with `08_export_hbase_feed.sh` |
| Hive runs + timings on the team VM | **To do on the VM:** run the steps below and keep the screenshots |
| Spark runs on the VM | Optional, only if Spark is installed (see step 6) |

## Folder layout

```
code/
  04a_job1_daily_channel.hql      Job 1  daily volume/value by channel + reconciliation
  04b_job2_customer_summary.hql   Job 2  customer/account activity, builds bank_customer_summary
  04c_job3_exception_review.hql   Job 3  high-value list, channel exception rates, rule checks
  05_run_jobs_timed.sh            runs each job N times, logs results/timing_log.csv
  06_load_perf_datasets.sh        optional: loads 20k / 200k-transaction datasets for timing
  06b_perf_ddl.hql                Hive DDL for those (same columns as Member 6)
  07_verify_outputs.py            compares VM output with results/expected_*/
  08_export_hbase_feed.sh         exports bank_customer_summary -> CSV for Member 9
  09_summarise_timings.py         timing_log.csv -> timing_summary.csv / report table
  spark/04_sample_jobs_spark.py   same SQL on Spark SQL (optional)
  reference/compute_reference_outputs.py   independent Python implementation
results/
  expected_small/ expected_large/ expected_xlarge/   expected outputs (CSV)
  customer_summary_for_hbase.csv                     HBase feed (small dataset)
perf_data/large, perf_data/xlarge                    timing datasets (see perf_data/README.md)
report/05_sample_jobs_and_evaluation.docx            report section (fill yellow placeholders)
slides/member7_query_outputs_and_measurements.pptx
docs/hbase_handoff_member9.md
```

## Runbook on the BigdataVM

Copy this folder to `~/member7_jobs` (for example through `/media/sf_vmshare`). Member 6's pipeline must already have been run, with the `bank_analytics` tables showing 200/300/2,000/500 rows.

```bash
# 1. Start services (same as Member 6)
/usr/share/hadoop/sbin/start-dfs.sh
/usr/share/hadoop/sbin/start-yarn.sh
nohup /usr/share/hive/bin/hive --service metastore > ~/metastore.log 2>&1 &
jps                                   # screenshot: running daemons

cd ~/member7_jobs

# 2. Run the three jobs on the small dataset, 3 trials each
bash code/05_run_jobs_timed.sh small 3          # screenshot: timing lines

# 3. Check the outputs against the expected files
python3 code/07_verify_outputs.py --engine hive --dataset small   # screenshot: ALL OUTPUTS MATCH

# 4. Export the HBase feed for Member 9
bash code/08_export_hbase_feed.sh               # screenshot: PASS HBase feed

# 5. (Recommended) timing on bigger data, so that Hive start-up does not dominate
bash code/06_load_perf_datasets.sh large
bash code/05_run_jobs_timed.sh large 3
python3 code/07_verify_outputs.py --engine hive --dataset large
bash code/06_load_perf_datasets.sh xlarge       # 200k transactions, ~17 MB
bash code/05_run_jobs_timed.sh xlarge 3
python3 code/07_verify_outputs.py --engine hive --dataset xlarge

# 6. (Only if Spark exists: `which spark-submit` or ls /usr/share/spark)
spark-submit code/spark/04_sample_jobs_spark.py --lake hdfs://localhost:8020/bank_lake --dataset small --trials 3
python3 code/07_verify_outputs.py --engine spark --dataset small
#   (use the namenode address from core-site.xml / fs.defaultFS if it differs)

# 7. Summary table for the report
python3 code/09_summarise_timings.py            # screenshot + paste into Table 5.4
```

To see the results in the Hive CLI (for screenshots of the query outputs):

```bash
hive --hivevar db=bank_analytics --hivevar lake=/bank_lake -f code/04a_job1_daily_channel.hql
```

Every Hive run's stdout and stderr is saved in `results/hive_outputs_<dataset>/`, so every number in the timing log can be traced back to its log file.

## Measurement rules used

* The same query text and data are used for every trial. Each trial starts a new Hive CLI, so `wall_seconds` includes CLI/JVM start-up, while `engine_reported_seconds` is the sum of Hive's own "Time taken" lines.
* Trial 1 is reported separately from the repeats. After trial 1 the OS file cache is warm, and the base tables are not cached explicitly.
* Hive and Spark are compared only if both actually ran on the same VM with the same dataset. Otherwise no speed-up is claimed.
* None of these timings is comparable with the bank's ~1-hour report (see report section 5.x.6).

## Reset / re-run

Job 2 overwrites only `/bank_lake/curated/customer_summary`. To remove everything Member 7 created:

```bash
hive -e "DROP TABLE IF EXISTS bank_analytics.bank_customer_summary;
         DROP DATABASE IF EXISTS bank_analytics_large CASCADE;
         DROP DATABASE IF EXISTS bank_analytics_xlarge CASCADE;"
hdfs dfs -rm -r -f /bank_lake/curated/customer_summary /bank_lake/curated/hbase_feed /bank_lake_perf
rm -rf results/hive_outputs_* results/spark_outputs_* results/timing_log.csv
```

Because the perf tables are external, `DROP DATABASE ... CASCADE` leaves their HDFS files in place, and the `hdfs dfs -rm` line removes them.
