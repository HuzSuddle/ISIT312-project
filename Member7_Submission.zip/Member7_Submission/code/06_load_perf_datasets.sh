#!/bin/bash
# =====================================================================
# MEMBER 7 - Load the larger timing datasets into separate HDFS folders
#            and separate Hive databases (optional, for measurements)
#
#   large  : 2,000 customers / 3,000 accounts / 20,000 transactions
#   xlarge : 20,000 customers / 30,000 accounts / 200,000 transactions
#
# Both were made with Member 5's generator (seed 312) and cleaned with
# Member 6's 02_clean_curate.py, so the format is identical to the small
# dataset. See perf_data/README.md.
#
# Usage:  bash code/06_load_perf_datasets.sh large
#         bash code/06_load_perf_datasets.sh xlarge
#
# The team's main tables (bank_analytics, /bank_lake) are NOT touched.
# =====================================================================
set -e
N=${1:-large}
cd "$(dirname "$0")/.."
HIVE_HOME=${HIVE_HOME:-/usr/share/hive}
HADOOP_HOME=${HADOOP_HOME:-/usr/share/hadoop}
export PATH=$PATH:$HADOOP_HOME/bin
LAKE=/bank_lake_perf/$N
SRC=perf_data/$N

[ -d "$SRC" ] || { echo "No folder $SRC"; exit 1; }

echo "[1/3] HDFS folders under $LAKE"
for T in customers accounts transactions; do
  hdfs dfs -mkdir -p "$LAKE/cleaned/$T"
  hdfs dfs -put -f "$SRC/cleaned/${T}_clean.csv" "$LAKE/cleaned/$T/"
done
hdfs dfs -mkdir -p "$LAKE/curated/regulatory_daily"
hdfs dfs -put -f "$SRC/curated/bank_regulatory_daily.csv" "$LAKE/curated/regulatory_daily/"

echo "[2/3] Hive database bank_analytics_$N"
"$HIVE_HOME/bin/hive" --hivevar db="bank_analytics_$N" --hivevar lake="$LAKE" \
    -f code/06b_perf_ddl.hql

echo "[3/3] Check"
hdfs dfs -ls -R "$LAKE"
"$HIVE_HOME/bin/hive" -S -e "SELECT COUNT(*) FROM bank_analytics_$N.bank_transactions;"
