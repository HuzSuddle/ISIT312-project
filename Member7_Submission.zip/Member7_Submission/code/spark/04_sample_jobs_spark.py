#!/usr/bin/env python3
"""
MEMBER 7 - Sample jobs on Spark SQL (optional engine)

Runs the SAME tagged SELECT statements that are in the Hive job files
(04a/04b/04c_*.hql) on Spark SQL, so both engines execute identical query
text on identical data. Each job is repeated --trials times and timed.

Data source (choose one):
  default         : read Member 6's cleaned CSVs from the lake path, e.g.
                    hdfs:///bank_lake/cleaned/transactions/
  --hive-tables   : read the Hive tables through the metastore instead
                    (needs Spark built with Hive support + hive-site.xml)

Usage (on the VM):
  spark-submit code/spark/04_sample_jobs_spark.py \
      --lake hdfs://localhost:8020/bank_lake --dataset small --trials 3

Outputs:
  results/spark_outputs/<query>.csv
  results/timing_log.csv  (rows appended, engine = spark-sql)

Written without f-strings so it also runs on the older Python 3 versions
that ship with Spark 2.x virtual machines.
"""
import argparse
import csv
import datetime
import os
import re
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CODE_DIR = os.path.dirname(HERE)
PROJECT_DIR = os.path.dirname(CODE_DIR)

JOB_FILES = [
    ("job1_daily_channel", "04a_job1_daily_channel.hql"),
    ("job2_customer_summary", "04b_job2_customer_summary.hql"),
    ("job3_exception_review", "04c_job3_exception_review.hql"),
]

TIMING_FIELDS = [
    "run_id", "run_timestamp", "engine", "engine_version", "dataset",
    "transactions_rows", "job", "trial", "trial_state", "wall_seconds",
    "engine_reported_seconds", "rows_returned", "exit_status", "notes",
]

TAG = re.compile(r"^--\s*@query\s+(\w+)\s*$")
INSERT = re.compile(r"^\s*INSERT\s+OVERWRITE\s+TABLE\s+(\w+)\s+", re.I | re.S)


def extract_tagged_queries(path):
    """Return [(name, sql, target_view_or_None)] for every '-- @query' block."""
    queries = []
    with open(path) as fh:
        lines = fh.read().splitlines()
    i = 0
    while i < len(lines):
        m = TAG.match(lines[i].strip())
        if not m:
            i += 1
            continue
        name = m.group(1)
        body = []
        i += 1
        while i < len(lines):
            body.append(lines[i])
            if lines[i].rstrip().endswith(";"):
                break
            i += 1
        sql = "\n".join(l for l in body if not l.strip().startswith("--"))
        sql = sql.strip().rstrip(";")
        target = None
        im = INSERT.match(sql)
        if im:
            target = im.group(1)
            sql = sql[im.end():]
        queries.append((name, sql, target))
        i += 1
    return queries


def build_views(spark, lake, use_hive_tables, db):
    from pyspark.sql.types import (StructType, StructField, StringType,
                                   DateType, TimestampType, DecimalType,
                                   IntegerType)
    if use_hive_tables:
        spark.sql("USE " + db)
        return
    S, D, TS = StringType(), DateType(), TimestampType()
    schemas = {
        "bank_customers": ("cleaned/customers", StructType([
            StructField("customer_id", S), StructField("customer_type", S),
            StructField("region_code", S), StructField("registration_date", D),
            StructField("status", S)])),
        "bank_accounts": ("cleaned/accounts", StructType([
            StructField("account_id", S), StructField("customer_id", S),
            StructField("account_type", S), StructField("opened_date", D),
            StructField("currency", S), StructField("status", S)])),
        "bank_transactions": ("cleaned/transactions", StructType([
            StructField("transaction_id", S), StructField("account_id", S),
            StructField("event_ts", TS), StructField("txn_date", D),
            StructField("amount", DecimalType(18, 2)),
            StructField("currency", S), StructField("transaction_type", S),
            StructField("channel", S), StructField("status", S)])),
        "bank_regulatory_daily": ("curated/regulatory_daily", StructType([
            StructField("txn_date", D), StructField("channel", S),
            StructField("transaction_type", S), StructField("status", S),
            StructField("transaction_count", IntegerType()),
            StructField("total_amount_etb", DecimalType(18, 2))])),
    }
    for view, (sub, schema) in schemas.items():
        path = lake.rstrip("/") + "/" + sub
        df = (spark.read.option("header", "true")
              .option("dateFormat", "yyyy-MM-dd")
              .option("timestampFormat", "yyyy-MM-dd HH:mm:ss")
              .option("mode", "FAILFAST")
              .schema(schema).csv(path))
        df.createOrReplaceTempView(view)


def write_rows(path, columns, rows):
    with open(path, "w") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(columns)
        for r in rows:
            w.writerow(["" if v is None else str(v) for v in r])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lake", default="hdfs:///bank_lake")
    ap.add_argument("--db", default="bank_analytics")
    ap.add_argument("--hive-tables", action="store_true")
    ap.add_argument("--dataset", default="small",
                    help="label written to the timing log (small / large)")
    ap.add_argument("--trials", type=int, default=3)
    ap.add_argument("--out", default=os.path.join(PROJECT_DIR, "results"))
    ap.add_argument("--shuffle-partitions", type=int, default=4,
                    help="spark.sql.shuffle.partitions (Spark default 200 is "
                         "far too many for a single small VM)")
    ap.add_argument("--master", default=None,
                    help="optional, e.g. local[2] or yarn")
    args = ap.parse_args()

    from pyspark.sql import SparkSession
    t0 = time.time()
    builder = (SparkSession.builder.appName("member7_sample_jobs")
               .config("spark.sql.shuffle.partitions", str(args.shuffle_partitions))
               .config("spark.ui.showConsoleProgress", "false"))
    if args.master:
        builder = builder.master(args.master)
    if args.hive_tables:
        builder = builder.enableHiveSupport()
    spark = builder.getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    startup = time.time() - t0
    version = spark.version

    build_views(spark, args.lake, args.hive_tables, args.db)
    txn_rows = spark.sql("SELECT COUNT(*) FROM bank_transactions").collect()[0][0]

    out_dir = os.path.join(args.out, "spark_outputs_" + args.dataset)
    if not os.path.isdir(out_dir):
        os.makedirs(out_dir)
    timing_path = os.path.join(args.out, "timing_log.csv")
    new_file = not os.path.exists(timing_path)
    run_id = "spark-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

    with open(timing_path, "a") as tf:
        tw = csv.DictWriter(tf, fieldnames=TIMING_FIELDS, lineterminator="\n")
        if new_file:
            tw.writeheader()
        for job, fname in JOB_FILES:
            queries = extract_tagged_queries(os.path.join(CODE_DIR, fname))
            for trial in range(1, args.trials + 1):
                status, rows_total, note = "OK", 0, ""
                cached = []
                start = time.time()
                try:
                    for name, sql, target in queries:
                        df = spark.sql(sql)
                        if target:
                            # Materialise the intermediate table in memory
                            # (Hive writes it to HDFS instead).
                            spark.catalog.dropTempView(target)
                            df = df.cache()
                            cached.append(df)
                            n = df.count()
                            df.createOrReplaceTempView(target)
                            rows = df.collect() if trial == 1 else None
                        else:
                            rows = df.collect()
                            n = len(rows)
                        rows_total += n
                        if trial == 1 and rows is not None:
                            write_rows(os.path.join(out_dir, name + ".csv"),
                                       df.columns, rows)
                except Exception as exc:  # record the failure honestly
                    status, note = "FAILED", str(exc).splitlines()[0][:200]
                wall = time.time() - start
                for c in cached:  # so the next trial cannot reuse the cache
                    c.unpersist()
                tw.writerow({
                    "run_id": run_id,
                    "run_timestamp": datetime.datetime.now().isoformat(),
                    "engine": "spark-sql",
                    "engine_version": version,
                    "dataset": args.dataset,
                    "transactions_rows": txn_rows,
                    "job": job,
                    "trial": trial,
                    "trial_state": "first-in-session" if trial == 1 else "repeat-in-session",
                    "wall_seconds": "%.3f" % wall,
                    "engine_reported_seconds": "",
                    "rows_returned": rows_total,
                    "exit_status": status,
                    "notes": note or ("session startup %.1fs not included; "
                                      "no explicit cache of base tables; shuffle partitions=%d"
                                      % (startup, args.shuffle_partitions)),
                })
                tf.flush()
                print("%-24s trial %d  %7.3fs  rows=%d  %s"
                      % (job, trial, wall, rows_total, status))
    spark.stop()
    print("Outputs : " + out_dir)
    print("Timings : " + timing_path)


if __name__ == "__main__":
    sys.exit(main())
