-- =====================================================================
-- MEMBER 7 - JOB 3: HIGH-VALUE AND EXCEPTION TRANSACTION REVIEW
-- Banking Data Lake (ISIT312) - synthetic data only
--
-- Input  : bank_transactions, bank_accounts, bank_customers (Member 6)
-- Output : job3_high_value_list   - transactions >= 100,000 ETB with context
--          job3_channel_exceptions - failure / pending rates per channel
--          job3_rule_checks        - business-rule violations (expected 0)
-- Purpose: an illustrative review list for compliance / operations staff.
--          The 100,000 ETB threshold is an assumption chosen for the demo;
--          it is NOT an official NBE reporting threshold.
--
-- Run    : hive --hivevar db=bank_analytics -f 04c_job3_exception_review.hql
-- =====================================================================

USE ${hivevar:db};
SET hive.cli.print.header=true;
SET hive.resultset.use.unique.column.names=false;

-- @query job3_high_value_list
-- All statuses are listed: a failed or pending high-value attempt is also
-- worth reviewing. Expected: 14 rows on the default dataset.
SELECT
    t.transaction_id,
    t.txn_date,
    t.account_id,
    a.customer_id,
    c.customer_type,
    a.account_type,
    t.transaction_type,
    t.channel,
    t.status,
    t.amount
FROM bank_transactions t
JOIN bank_accounts  a ON t.account_id  = a.account_id
JOIN bank_customers c ON a.customer_id = c.customer_id
WHERE t.amount >= 100000
ORDER BY t.amount DESC, t.transaction_id;

-- @query job3_channel_exceptions
SELECT
    t.channel,
    COUNT(*)                                                     AS attempted_count,
    SUM(CASE WHEN t.status = 'FAILED'  THEN 1 ELSE 0 END)        AS failed_count,
    SUM(CASE WHEN t.status = 'PENDING' THEN 1 ELSE 0 END)        AS pending_count,
    CAST(100.0 * SUM(CASE WHEN t.status = 'FAILED' THEN 1 ELSE 0 END)
         / COUNT(*) AS DECIMAL(6,2))                             AS failed_pct,
    SUM(CASE WHEN t.amount >= 100000 THEN 1 ELSE 0 END)          AS high_value_count,
    CAST(MAX(t.amount) AS DECIMAL(18,2))                         AS max_amount_etb
FROM bank_transactions t
GROUP BY t.channel
ORDER BY t.channel;

-- @query job3_rule_checks
-- Each column counts violations of a data rule. Expected: all 0.
SELECT
    SUM(CASE WHEN a.account_id IS NULL THEN 1 ELSE 0 END)                     AS orphan_transactions,
    SUM(CASE WHEN a.account_id IS NOT NULL AND a.status <> 'ACTIVE'
             THEN 1 ELSE 0 END)                                               AS txns_on_non_active_accounts,
    SUM(CASE WHEN a.account_id IS NOT NULL AND t.txn_date < a.opened_date
             THEN 1 ELSE 0 END)                                               AS txns_before_account_opened,
    SUM(CASE WHEN t.amount <= 0 THEN 1 ELSE 0 END)                            AS non_positive_amounts,
    SUM(CASE WHEN t.txn_date <> TO_DATE(t.event_ts) THEN 1 ELSE 0 END)        AS txn_date_mismatch
FROM bank_transactions t
LEFT JOIN bank_accounts a ON t.account_id = a.account_id;
