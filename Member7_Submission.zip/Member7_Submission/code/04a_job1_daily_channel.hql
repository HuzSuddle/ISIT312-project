-- =====================================================================
-- MEMBER 7 - JOB 1: DAILY TRANSACTION VOLUME AND VALUE BY CHANNEL
-- Banking Data Lake (ISIT312) - synthetic data only
--
-- Input  : bank_transactions (Member 6, cleaned zone)
--          bank_regulatory_daily (Member 6, curated zone) - reconciliation only
-- Output : one row per txn_date x channel (31 days x 5 channels = 155 rows)
-- Purpose: illustrative daily channel report of the kind used for
--          operational and regulatory reporting. It is NOT an official
--          National Bank of Ethiopia report format.
--
-- Run    : hive --hivevar db=bank_analytics -f 04a_job1_daily_channel.hql
-- Engine : written for Hive 2.1.1; the tagged SELECTs also run unchanged
--          in Spark SQL (see spark/04_sample_jobs_spark.py)
-- =====================================================================

USE ${hivevar:db};
SET hive.cli.print.header=true;
SET hive.resultset.use.unique.column.names=false;

-- @query job1_daily_channel
-- Value totals use COMPLETED transactions only (agreed rule from Member 5).
-- Pending and failed attempts are counted separately so nothing is hidden.
SELECT
    t.txn_date,
    t.channel,
    COUNT(*)                                                            AS attempted_count,
    SUM(CASE WHEN t.status = 'COMPLETED' THEN 1 ELSE 0 END)             AS completed_count,
    SUM(CASE WHEN t.status = 'PENDING'   THEN 1 ELSE 0 END)             AS pending_count,
    SUM(CASE WHEN t.status = 'FAILED'    THEN 1 ELSE 0 END)             AS failed_count,
    CAST(SUM(CASE WHEN t.status = 'COMPLETED' THEN t.amount ELSE 0 END)
         AS DECIMAL(18,2))                                              AS completed_value_etb
FROM bank_transactions t
GROUP BY t.txn_date, t.channel
ORDER BY t.txn_date, t.channel;

-- @query job1_channel_totals
-- Period totals per channel; must match Member 5 reference figures.
SELECT
    t.channel,
    SUM(CASE WHEN t.status = 'COMPLETED' THEN 1 ELSE 0 END)             AS completed_count,
    CAST(SUM(CASE WHEN t.status = 'COMPLETED' THEN t.amount ELSE 0 END)
         AS DECIMAL(18,2))                                              AS completed_value_etb
FROM bank_transactions t
GROUP BY t.channel
ORDER BY t.channel;

-- @query job1_reconciliation
-- Data-quality check: the detailed table and Member 6's curated table must
-- agree for every date and channel. Expected result: mismatched_groups = 0.
SELECT
    COUNT(*)                                                            AS groups_compared,
    SUM(CASE WHEN d.completed_count = COALESCE(r.cur_count, 0)
              AND d.completed_value_etb = COALESCE(r.cur_value, 0)
             THEN 0 ELSE 1 END)                                         AS mismatched_groups
FROM (
    SELECT txn_date, channel,
           SUM(CASE WHEN status = 'COMPLETED' THEN 1 ELSE 0 END)        AS completed_count,
           CAST(SUM(CASE WHEN status = 'COMPLETED' THEN amount ELSE 0 END)
                AS DECIMAL(18,2))                                       AS completed_value_etb
    FROM bank_transactions
    GROUP BY txn_date, channel
) d
LEFT JOIN (
    SELECT txn_date, channel,
           SUM(transaction_count)                                       AS cur_count,
           CAST(SUM(total_amount_etb) AS DECIMAL(18,2))                 AS cur_value
    FROM bank_regulatory_daily
    WHERE status = 'COMPLETED'
    GROUP BY txn_date, channel
) r
ON d.txn_date = r.txn_date AND d.channel = r.channel;
