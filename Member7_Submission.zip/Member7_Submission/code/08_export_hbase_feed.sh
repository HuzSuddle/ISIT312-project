#!/bin/bash
# =====================================================================
# MEMBER 7 - Export the customer summary for Member 9 (HBase)
#
# Reads the Hive table bank_customer_summary (built by Job 2), writes
# results/customer_summary_for_hbase_vm.csv with a header row, copies it to
# HDFS (/bank_lake/curated/hbase_feed/) and checks it against the expected
# file. Run after 05_run_jobs_timed.sh (small dataset).
# =====================================================================
set -e
cd "$(dirname "$0")/.."
HIVE_HOME=${HIVE_HOME:-/usr/share/hive}
HADOOP_HOME=${HADOOP_HOME:-/usr/share/hadoop}
export PATH=$PATH:$HADOOP_HOME/bin
OUT=results/customer_summary_for_hbase_vm.csv

"$HIVE_HOME/bin/hive" -S -e "
SET hive.cli.print.header=true;
SET hive.resultset.use.unique.column.names=false;
USE bank_analytics;
SELECT * FROM bank_customer_summary ORDER BY customer_id;" 2>/dev/null \
  | tr '\t' ',' > "$OUT"

echo "Rows (excluding header): $(( $(wc -l < "$OUT") - 1 ))   (expected 200)"
head -3 "$OUT"

hdfs dfs -mkdir -p /bank_lake/curated/hbase_feed
hdfs dfs -put -f "$OUT" /bank_lake/curated/hbase_feed/customer_summary_for_hbase.csv
hdfs dfs -ls /bank_lake/curated/hbase_feed

python3 code/07_verify_outputs.py --hbase-csv "$OUT"
