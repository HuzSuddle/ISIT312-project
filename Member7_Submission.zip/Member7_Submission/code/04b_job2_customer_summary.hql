-- =====================================================================
-- MEMBER 7 - JOB 2: CUSTOMER AND ACCOUNT ACTIVITY SUMMARY
-- Banking Data Lake (ISIT312) - synthetic data only
--
-- Input  : bank_customers, bank_accounts, bank_transactions (Member 6)
-- Output : bank_customer_summary  - new curated table, one row per customer
--                                   (200 rows), also the HBase feed for Member 9
--          job2_segment_summary   - totals by customer_type
-- Purpose: customer-level view (accounts held, activity, value) that today
--          would need several source systems combined.
--
-- Run    : hive --hivevar db=bank_analytics --hivevar lake=/bank_lake \
--               -f 04b_job2_customer_summary.hql
-- Writes : ${lake}/curated/customer_summary  (new folder; Member 6's
--          tables and folders are not modified)
-- =====================================================================

USE ${hivevar:db};
SET hive.cli.print.header=true;
SET hive.resultset.use.unique.column.names=false;

CREATE EXTERNAL TABLE IF NOT EXISTS bank_customer_summary (
    customer_id           STRING,
    customer_type         STRING,
    region_code           STRING,
    customer_status       STRING,
    registration_date     DATE,
    num_accounts          BIGINT,
    num_active_accounts   BIGINT,
    txn_count_all         BIGINT,
    completed_txn_count   BIGINT,
    pending_txn_count     BIGINT,
    failed_txn_count      BIGINT,
    completed_value_etb   DECIMAL(18,2),
    avg_completed_etb     DECIMAL(18,2),
    high_value_txn_count  BIGINT,
    first_txn_date        STRING,
    last_txn_date         STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '${hivevar:lake}/curated/customer_summary';

-- @query bank_customer_summary
-- Every customer is kept (LEFT JOIN), including those with no transactions,
-- so the HBase lookup can answer for any customer_id.
-- High-value threshold 100,000 ETB is illustrative, not a regulatory rule.
INSERT OVERWRITE TABLE bank_customer_summary
SELECT
    c.customer_id,
    c.customer_type,
    c.region_code,
    c.status                                                  AS customer_status,
    c.registration_date,
    COALESCE(a.num_accounts, 0)                               AS num_accounts,
    COALESCE(a.num_active_accounts, 0)                        AS num_active_accounts,
    COALESCE(x.txn_count_all, 0)                              AS txn_count_all,
    COALESCE(x.completed_txn_count, 0)                        AS completed_txn_count,
    COALESCE(x.pending_txn_count, 0)                          AS pending_txn_count,
    COALESCE(x.failed_txn_count, 0)                           AS failed_txn_count,
    CAST(COALESCE(x.completed_value_etb, 0) AS DECIMAL(18,2)) AS completed_value_etb,
    CAST(CASE WHEN COALESCE(x.completed_txn_count, 0) = 0 THEN 0
              ELSE x.completed_value_etb / x.completed_txn_count
         END AS DECIMAL(18,2))                                AS avg_completed_etb,
    COALESCE(x.high_value_txn_count, 0)                       AS high_value_txn_count,
    COALESCE(CAST(x.first_txn_date AS STRING), '')            AS first_txn_date,
    COALESCE(CAST(x.last_txn_date AS STRING), '')             AS last_txn_date
FROM bank_customers c
LEFT JOIN (
    SELECT customer_id,
           COUNT(*)                                               AS num_accounts,
           SUM(CASE WHEN status = 'ACTIVE' THEN 1 ELSE 0 END)     AS num_active_accounts
    FROM bank_accounts
    GROUP BY customer_id
) a ON c.customer_id = a.customer_id
LEFT JOIN (
    SELECT ac.customer_id,
           COUNT(*)                                                         AS txn_count_all,
           SUM(CASE WHEN t.status = 'COMPLETED' THEN 1 ELSE 0 END)          AS completed_txn_count,
           SUM(CASE WHEN t.status = 'PENDING'   THEN 1 ELSE 0 END)          AS pending_txn_count,
           SUM(CASE WHEN t.status = 'FAILED'    THEN 1 ELSE 0 END)          AS failed_txn_count,
           SUM(CASE WHEN t.status = 'COMPLETED' THEN t.amount ELSE 0 END)   AS completed_value_etb,
           SUM(CASE WHEN t.amount >= 100000 THEN 1 ELSE 0 END)              AS high_value_txn_count,
           MIN(t.txn_date)                                                  AS first_txn_date,
           MAX(t.txn_date)                                                  AS last_txn_date
    FROM bank_transactions t
    JOIN bank_accounts ac ON t.account_id = ac.account_id
    GROUP BY ac.customer_id
) x ON c.customer_id = x.customer_id;

-- @query job2_segment_summary
-- Active-account / active-customer summary by segment.
-- "Transacting" = at least one transaction of any status in the period.
SELECT
    customer_type,
    COUNT(*)                                                    AS customers,
    SUM(CASE WHEN customer_status = 'ACTIVE' THEN 1 ELSE 0 END) AS active_status_customers,
    SUM(CASE WHEN txn_count_all > 0 THEN 1 ELSE 0 END)          AS transacting_customers,
    SUM(num_accounts)                                           AS accounts,
    SUM(num_active_accounts)                                    AS active_accounts,
    SUM(completed_txn_count)                                    AS completed_txns,
    CAST(SUM(completed_value_etb) AS DECIMAL(18,2))             AS completed_value_etb
FROM bank_customer_summary
GROUP BY customer_type
ORDER BY customer_type;

-- @query job2_activity_checks
-- Checks against Member 5 reference figures:
-- 200 customers, 300 accounts, 166 transacting customers,
-- 238 transacting accounts, 1,788 completed / 16,822,824.96 ETB.
-- (Hive 2.1 has no scalar subqueries in SELECT, so single-row
--  aggregates are combined with CROSS JOIN.)
SELECT
    s.summary_rows,
    s.accounts_in_summary,
    s.transacting_customers,
    ta.transacting_accounts,
    s.completed_txns,
    s.completed_value_etb
FROM (
    SELECT COUNT(*)                                            AS summary_rows,
           SUM(num_accounts)                                   AS accounts_in_summary,
           SUM(CASE WHEN txn_count_all > 0 THEN 1 ELSE 0 END)  AS transacting_customers,
           SUM(completed_txn_count)                            AS completed_txns,
           CAST(SUM(completed_value_etb) AS DECIMAL(18,2))     AS completed_value_etb
    FROM bank_customer_summary
) s
CROSS JOIN (
    SELECT COUNT(DISTINCT account_id)                          AS transacting_accounts
    FROM bank_transactions
) ta;
