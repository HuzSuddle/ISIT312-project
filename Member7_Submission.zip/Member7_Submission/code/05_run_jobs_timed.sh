#!/bin/bash
# =====================================================================
# MEMBER 7 - Run the three Hive jobs repeatedly and log the timings
#
# Usage (from the member7 folder on the VM):
#   bash code/05_run_jobs_timed.sh            # small dataset, 3 trials
#   bash code/05_run_jobs_timed.sh large 3    # needs 06_load_perf_datasets.sh
#   bash code/05_run_jobs_timed.sh xlarge 3
#
# For every job and trial it records, in results/timing_log.csv:
#   wall_seconds            - whole "hive -f" call, including CLI/JVM start
#   engine_reported_seconds - sum of Hive's own "Time taken" lines
# Hive stdout/stderr of every run is kept in results/hive_outputs_<dataset>/
# so each timing can be traced back to its log.
#
# Nothing in Member 6's tables or folders is modified. Job 2 (re)writes
# only <lake>/curated/customer_summary.
# =====================================================================

DATASET=${1:-small}
TRIALS=${2:-3}
cd "$(dirname "$0")/.." || exit 1
PROJECT=$(pwd)

HIVE_HOME=${HIVE_HOME:-/usr/share/hive}
HADOOP_HOME=${HADOOP_HOME:-/usr/share/hadoop}
HIVE="$HIVE_HOME/bin/hive"
export PATH=$PATH:$HADOOP_HOME/bin

case "$DATASET" in
  small)  DB=bank_analytics;        LAKE=/bank_lake ;;
  large)  DB=bank_analytics_large;  LAKE=/bank_lake_perf/large ;;
  xlarge) DB=bank_analytics_xlarge; LAKE=/bank_lake_perf/xlarge ;;
  *) echo "dataset must be small, large or xlarge"; exit 1 ;;
esac

OUT="$PROJECT/results/hive_outputs_$DATASET"
LOG="$PROJECT/results/timing_log.csv"
mkdir -p "$OUT"
if [ ! -f "$LOG" ]; then
  echo "run_id,run_timestamp,engine,engine_version,dataset,transactions_rows,job,trial,trial_state,wall_seconds,engine_reported_seconds,rows_returned,exit_status,notes" > "$LOG"
fi

RUN_ID="hive-$(date +%Y%m%d-%H%M%S)"
HIVE_VER=$("$HIVE" --version 2>/dev/null | grep -m1 -o 'Hive [0-9.]*' | tr -d '\n')
HADOOP_VER=$(hadoop version 2>/dev/null | head -1 | tr -d '\n')
EXEC_ENGINE=$("$HIVE" -S -e "set hive.execution.engine;" 2>/dev/null | tail -1)
TXN_ROWS=$("$HIVE" -S -e "SELECT COUNT(*) FROM $DB.bank_transactions;" 2>/dev/null | tail -1)
CPU=$(nproc 2>/dev/null)
MEM=$(free -m 2>/dev/null | awk '/Mem:/ {print $2 " MB"}')

{
  echo "run_id=$RUN_ID"
  echo "dataset=$DATASET database=$DB lake=$LAKE transactions=$TXN_ROWS"
  echo "hive=$HIVE_VER  hadoop=$HADOOP_VER  $EXEC_ENGINE"
  echo "vm_cpus=$CPU  vm_memory=$MEM"
  uname -a
} | tee "$OUT/environment_$RUN_ID.txt"

for JOB in 04a_job1_daily_channel 04b_job2_customer_summary 04c_job3_exception_review; do
  SHORT=$(echo "$JOB" | cut -d_ -f2-)
  PRINTED=$(( $(grep -c '^-- @query' "code/$JOB.hql") - $(grep -c '^INSERT OVERWRITE' "code/$JOB.hql") ))
  for T in $(seq 1 "$TRIALS"); do
    START=$(date +%s.%N)
    "$HIVE" --hivevar db="$DB" --hivevar lake="$LAKE" -f "code/$JOB.hql" \
        > "$OUT/${SHORT}_trial$T.out" 2> "$OUT/${SHORT}_trial$T.err"
    RC=$?
    END=$(date +%s.%N)
    WALL=$(awk -v s="$START" -v e="$END" 'BEGIN {printf "%.3f", e - s}')
    REPORTED=$(grep -o 'Time taken: [0-9.]* seconds' "$OUT/${SHORT}_trial$T.err" \
               | awk '{s += $3} END {printf "%.3f", s}')
    LINES=$(grep -c . "$OUT/${SHORT}_trial$T.out")
    ROWS=$(( LINES - PRINTED ))
    if [ "$RC" -eq 0 ]; then STATUS=OK; else STATUS=FAILED; fi
    if [ "$T" -eq 1 ]; then STATE=first-run; else STATE=repeat; fi
    echo "$RUN_ID,$(date -Iseconds),hive,$HIVE_VER,$DATASET,$TXN_ROWS,$SHORT,$T,$STATE,$WALL,$REPORTED,$ROWS,$STATUS,new CLI per trial; $EXEC_ENGINE" >> "$LOG"
    printf "%-22s trial %s  wall %8ss  hive-reported %8ss  rows %5s  %s\n" \
        "$SHORT" "$T" "$WALL" "$REPORTED" "$ROWS" "$STATUS"
  done
done

echo
echo "Timings appended to $LOG"
echo "Next: python3 code/07_verify_outputs.py --engine hive --dataset $DATASET"
