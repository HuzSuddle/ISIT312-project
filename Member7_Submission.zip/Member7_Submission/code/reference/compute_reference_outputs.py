#!/usr/bin/env python3
"""
MEMBER 7 - Independent reference implementation of the three jobs.

Computes the expected job outputs with plain Python (standard library only)
from Member 6's cleaned CSV files. It does not use Hive or Spark, so it is an
independent check: if Hive/Spark output matches these files, the SQL is right.

Usage:
  python3 code/reference/compute_reference_outputs.py \
      --cleaned <folder with customers_clean.csv, accounts_clean.csv,
                 transactions_clean.csv> \
      --curated <folder with bank_regulatory_daily.csv> \
      --out results/expected

No f-strings, so it runs on older Python 3 versions as well.
"""
import argparse
import csv
import os
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP

HIGH_VALUE = Decimal("100000")
CENT = Decimal("0.01")


def q2(x):
    return str(Decimal(x).quantize(CENT, rounding=ROUND_HALF_UP))


def read(path):
    with open(path, newline="") as fh:
        return list(csv.DictReader(fh))


def write(path, header, rows):
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(header)
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cleaned", required=True)
    ap.add_argument("--curated", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    if not os.path.isdir(a.out):
        os.makedirs(a.out)

    cust = read(os.path.join(a.cleaned, "customers_clean.csv"))
    acc = read(os.path.join(a.cleaned, "accounts_clean.csv"))
    txn = read(os.path.join(a.cleaned, "transactions_clean.csv"))
    cur = read(os.path.join(a.curated, "bank_regulatory_daily.csv"))
    acc_by_id = dict((r["account_id"], r) for r in acc)
    cust_by_id = dict((r["customer_id"], r) for r in cust)
    for r in txn:
        r["amt"] = Decimal(r["amount"])

    # ---------------- Job 1 ----------------
    g = defaultdict(lambda: [0, 0, 0, 0, Decimal("0")])
    for r in txn:
        k = (r["txn_date"], r["channel"])
        g[k][0] += 1
        if r["status"] == "COMPLETED":
            g[k][1] += 1
            g[k][4] += r["amt"]
        elif r["status"] == "PENDING":
            g[k][2] += 1
        elif r["status"] == "FAILED":
            g[k][3] += 1
    write(os.path.join(a.out, "job1_daily_channel.csv"),
          ["txn_date", "channel", "attempted_count", "completed_count",
           "pending_count", "failed_count", "completed_value_etb"],
          [[k[0], k[1], v[0], v[1], v[2], v[3], q2(v[4])]
           for k, v in sorted(g.items())])

    ch = defaultdict(lambda: [0, Decimal("0")])
    for r in txn:
        if r["status"] == "COMPLETED":
            ch[r["channel"]][0] += 1
            ch[r["channel"]][1] += r["amt"]
    write(os.path.join(a.out, "job1_channel_totals.csv"),
          ["channel", "completed_count", "completed_value_etb"],
          [[k, v[0], q2(v[1])] for k, v in sorted(ch.items())])

    cg = defaultdict(lambda: [0, Decimal("0")])
    for r in cur:
        if r["status"] == "COMPLETED":
            k = (r["txn_date"], r["channel"])
            cg[k][0] += int(r["transaction_count"])
            cg[k][1] += Decimal(r["total_amount_etb"])
    mism = sum(1 for k, v in g.items()
               if (v[1], v[4]) != tuple(cg.get(k, [0, Decimal("0")])))
    write(os.path.join(a.out, "job1_reconciliation.csv"),
          ["groups_compared", "mismatched_groups"], [[len(g), mism]])

    # ---------------- Job 2 ----------------
    accs = defaultdict(lambda: [0, 0])
    for r in acc:
        accs[r["customer_id"]][0] += 1
        if r["status"] == "ACTIVE":
            accs[r["customer_id"]][1] += 1
    tx = defaultdict(lambda: {"all": 0, "c": 0, "p": 0, "f": 0,
                              "v": Decimal("0"), "hv": 0, "d": []})
    for r in txn:
        cid = acc_by_id[r["account_id"]]["customer_id"]
        s = tx[cid]
        s["all"] += 1
        s["d"].append(r["txn_date"])
        if r["status"] == "COMPLETED":
            s["c"] += 1
            s["v"] += r["amt"]
        elif r["status"] == "PENDING":
            s["p"] += 1
        elif r["status"] == "FAILED":
            s["f"] += 1
        if r["amt"] >= HIGH_VALUE:
            s["hv"] += 1
    summary = []
    for c in sorted(cust, key=lambda r: r["customer_id"]):
        cid = c["customer_id"]
        s = tx.get(cid)
        na, naa = accs.get(cid, [0, 0])
        if s:
            avg = q2(s["v"] / s["c"]) if s["c"] else "0.00"
            row = [cid, c["customer_type"], c["region_code"], c["status"],
                   c["registration_date"], na, naa, s["all"], s["c"], s["p"],
                   s["f"], q2(s["v"]), avg, s["hv"], min(s["d"]), max(s["d"])]
        else:
            row = [cid, c["customer_type"], c["region_code"], c["status"],
                   c["registration_date"], na, naa, 0, 0, 0, 0, "0.00",
                   "0.00", 0, "", ""]
        summary.append(row)
    sum_header = ["customer_id", "customer_type", "region_code",
                  "customer_status", "registration_date", "num_accounts",
                  "num_active_accounts", "txn_count_all",
                  "completed_txn_count", "pending_txn_count",
                  "failed_txn_count", "completed_value_etb",
                  "avg_completed_etb", "high_value_txn_count",
                  "first_txn_date", "last_txn_date"]
    write(os.path.join(a.out, "bank_customer_summary.csv"), sum_header, summary)

    seg = defaultdict(lambda: [0, 0, 0, 0, 0, 0, Decimal("0")])
    for r in summary:
        s = seg[r[1]]
        s[0] += 1
        s[1] += 1 if r[3] == "ACTIVE" else 0
        s[2] += 1 if r[7] > 0 else 0
        s[3] += r[5]
        s[4] += r[6]
        s[5] += r[8]
        s[6] += Decimal(r[11])
    write(os.path.join(a.out, "job2_segment_summary.csv"),
          ["customer_type", "customers", "active_status_customers",
           "transacting_customers", "accounts", "active_accounts",
           "completed_txns", "completed_value_etb"],
          [[k] + v[:6] + [q2(v[6])] for k, v in sorted(seg.items())])
    write(os.path.join(a.out, "job2_activity_checks.csv"),
          ["summary_rows", "accounts_in_summary", "transacting_customers",
           "transacting_accounts", "completed_txns", "completed_value_etb"],
          [[len(summary), sum(r[5] for r in summary),
            sum(1 for r in summary if r[7] > 0),
            len(set(r["account_id"] for r in txn)),
            sum(r[8] for r in summary),
            q2(sum(Decimal(r[11]) for r in summary))]])

    # ---------------- Job 3 ----------------
    hv = [r for r in txn if r["amt"] >= HIGH_VALUE]
    hv.sort(key=lambda r: (-r["amt"], r["transaction_id"]))
    rows = []
    for r in hv:
        ac = acc_by_id[r["account_id"]]
        cu = cust_by_id[ac["customer_id"]]
        rows.append([r["transaction_id"], r["txn_date"], r["account_id"],
                     ac["customer_id"], cu["customer_type"],
                     ac["account_type"], r["transaction_type"], r["channel"],
                     r["status"], q2(r["amt"])])
    write(os.path.join(a.out, "job3_high_value_list.csv"),
          ["transaction_id", "txn_date", "account_id", "customer_id",
           "customer_type", "account_type", "transaction_type", "channel",
           "status", "amount"], rows)

    ex = defaultdict(lambda: [0, 0, 0, 0, Decimal("0")])
    for r in txn:
        e = ex[r["channel"]]
        e[0] += 1
        e[1] += 1 if r["status"] == "FAILED" else 0
        e[2] += 1 if r["status"] == "PENDING" else 0
        e[3] += 1 if r["amt"] >= HIGH_VALUE else 0
        e[4] = max(e[4], r["amt"])
    write(os.path.join(a.out, "job3_channel_exceptions.csv"),
          ["channel", "attempted_count", "failed_count", "pending_count",
           "failed_pct", "high_value_count", "max_amount_etb"],
          [[k, v[0], v[1], v[2], q2(Decimal(100 * v[1]) / v[0]), v[3],
            q2(v[4])] for k, v in sorted(ex.items())])

    orphan = sum(1 for r in txn if r["account_id"] not in acc_by_id)
    inactive = sum(1 for r in txn if r["account_id"] in acc_by_id
                   and acc_by_id[r["account_id"]]["status"] != "ACTIVE")
    before = sum(1 for r in txn if r["account_id"] in acc_by_id
                 and r["txn_date"] < acc_by_id[r["account_id"]]["opened_date"])
    nonpos = sum(1 for r in txn if r["amt"] <= 0)
    mism_d = sum(1 for r in txn if r["event_ts"][:10] != r["txn_date"])
    write(os.path.join(a.out, "job3_rule_checks.csv"),
          ["orphan_transactions", "txns_on_non_active_accounts",
           "txns_before_account_opened", "non_positive_amounts",
           "txn_date_mismatch"], [[orphan, inactive, before, nonpos, mism_d]])
    print("Reference outputs written to " + a.out)


if __name__ == "__main__":
    main()
