#!/usr/bin/env python3
"""
MEMBER 7 - Summarise results/timing_log.csv into a small result table.

For every engine x dataset x job it reports the number of successful trials,
the first-run time, and the median / min / max of the repeat runs. Failed
trials are counted but never averaged in.

Writes results/timing_summary.csv and prints a table that can be pasted
into the report (Table 5.x).

Usage: python3 code/09_summarise_timings.py
"""
import csv
import os
from collections import OrderedDict

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(os.path.dirname(HERE), "results")


def median(xs):
    xs = sorted(xs)
    n = len(xs)
    if not n:
        return None
    return xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) / 2.0


def fmt(x):
    return "" if x is None else "%.2f" % x


def main():
    path = os.path.join(RES, "timing_log.csv")
    with open(path) as fh:
        rows = list(csv.DictReader(fh))
    groups = OrderedDict()
    for r in rows:
        k = (r["engine"], r["engine_version"], r["dataset"],
             r["transactions_rows"], r["job"])
        groups.setdefault(k, []).append(r)

    out = []
    for (eng, ver, ds, n, job), rs in groups.items():
        ok = [r for r in rs if r["exit_status"] == "OK"]
        first = [float(r["wall_seconds"]) for r in ok if r["trial"] == "1"]
        rep = [float(r["wall_seconds"]) for r in ok if r["trial"] != "1"]
        rep_eng = [float(r["engine_reported_seconds"]) for r in ok
                   if r["trial"] != "1" and r["engine_reported_seconds"]]
        out.append(OrderedDict([
            ("engine", eng), ("version", ver), ("dataset", ds),
            ("transactions", n), ("job", job),
            ("ok_trials", len(ok)), ("failed_trials", len(rs) - len(ok)),
            ("first_run_wall_s", fmt(first[0] if first else None)),
            ("repeat_median_wall_s", fmt(median(rep))),
            ("repeat_min_wall_s", fmt(min(rep) if rep else None)),
            ("repeat_max_wall_s", fmt(max(rep) if rep else None)),
            ("repeat_median_engine_s", fmt(median(rep_eng))),
        ]))

    with open(os.path.join(RES, "timing_summary.csv"), "w") as fh:
        w = csv.DictWriter(fh, fieldnames=list(out[0].keys()),
                           lineterminator="\n")
        w.writeheader()
        w.writerows(out)

    cols = ["engine", "dataset", "transactions", "job", "ok_trials",
            "first_run_wall_s", "repeat_median_wall_s",
            "repeat_median_engine_s"]
    widths = [max(len(c), max(len(str(o[c])) for o in out)) for c in cols]
    line = "  ".join(c.ljust(wd) for c, wd in zip(cols, widths))
    print(line)
    print("-" * len(line))
    for o in out:
        print("  ".join(str(o[c]).ljust(wd) for c, wd in zip(cols, widths)))
    print("\nSaved results/timing_summary.csv")


if __name__ == "__main__":
    main()
