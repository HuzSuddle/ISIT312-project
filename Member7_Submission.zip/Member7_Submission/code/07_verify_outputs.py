#!/usr/bin/env python3
"""
MEMBER 7 - Verify job outputs produced on the VM against the expected files.

Works with both engines:
  * Hive : the stdout captured by 05_run_jobs_timed.sh
           (results/hive_outputs_<dataset>/<job>_trial1.out, tab-separated,
            one header line per query)
  * Spark: the CSV files written by spark/04_sample_jobs_spark.py
           (results/spark_outputs_<dataset>/<query>.csv)

Numbers are compared numerically (Hive 2.1 may print 100.5 for 100.50).
Rows of bank_customer_summary are compared after sorting (no ORDER BY).

Usage:
  python3 code/07_verify_outputs.py --engine hive  --dataset small
  python3 code/07_verify_outputs.py --engine spark --dataset large
  python3 code/07_verify_outputs.py --hbase-csv results/customer_summary_for_hbase_vm.csv

Exit code 0 = everything matched. A report is written to
results/verification_<engine>_<dataset>.txt
"""
import argparse
import csv
import glob
import os
import sys
from decimal import Decimal, InvalidOperation

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.dirname(HERE)
UNORDERED = {"bank_customer_summary"}


def norm(v):
    v = v.strip()
    if v in ("NULL", "\\N"):
        return ""
    try:
        return Decimal(v).normalize()
    except InvalidOperation:
        return v


def load_csv(path):
    with open(path, newline="") as fh:
        return list(csv.reader(fh))


def expected_tables(dataset):
    d = os.path.join(PROJECT, "results", "expected_" + dataset)
    out = {}
    for p in sorted(glob.glob(os.path.join(d, "*.csv"))):
        rows = load_csv(p)
        out[os.path.basename(p)[:-4]] = rows
    return out


def parse_hive_stdout(path, expected):
    """Split Hive CLI stdout into result sets using the known header lines."""
    headers = dict(("\t".join(v[0]), k) for k, v in expected.items())
    found, current = {}, None
    with open(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if line in headers:
                current = headers[line]
                found[current] = [line.split("\t")]
                continue
            if current is None or not line.strip():
                continue
            if line.startswith(("OK", "Time taken", "WARNING", "SLF4J",
                                "Logging initialized", "Query ID",
                                "Total jobs", "Launching", "Stage-",
                                "MapReduce", "Ended Job", "Hadoop job",
                                "In order to", "  set ", "Starting Job",
                                "Kill Command", "Loading data", "Table ")):
                current = None if line.startswith(("OK", "Time taken")) else current
                continue
            parts = line.split("\t")
            if len(parts) == len(found[current][0]):
                found[current].append(parts)
    return found


def compare(name, exp, got):
    if got is None:
        return False, "missing from output"
    if [h.strip() for h in got[0]] != exp[0]:
        return False, "header differs: %s" % got[0]
    e = [[norm(x) for x in r] for r in exp[1:]]
    g = [[norm(x) for x in r] for r in got[1:]]
    if name in UNORDERED:
        e, g = sorted(e, key=str), sorted(g, key=str)
    if len(e) != len(g):
        return False, "row count %d, expected %d" % (len(g), len(e))
    for i, (a, b) in enumerate(zip(e, g)):
        if a != b:
            return False, "first difference at row %d: got %s expected %s" % (
                i + 1, got[1:][i], exp[1:][i])
    return True, "%d rows match" % len(e)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", choices=["hive", "spark"])
    ap.add_argument("--dataset", default="small")
    ap.add_argument("--hbase-csv", help="check an exported HBase feed file")
    a = ap.parse_args()
    expected = expected_tables(a.dataset)
    lines, ok_all = [], True

    if a.hbase_csv:
        ok, msg = compare("bank_customer_summary",
                          expected["bank_customer_summary"],
                          load_csv(a.hbase_csv))
        print(("PASS " if ok else "FAIL ") + "HBase feed: " + msg)
        return 0 if ok else 1

    if a.engine == "hive":
        got = {}
        d = os.path.join(PROJECT, "results", "hive_outputs_" + a.dataset)
        for p in sorted(glob.glob(os.path.join(d, "*_trial1.out"))):
            got.update(parse_hive_stdout(p, expected))
        # bank_customer_summary is written to a table, not printed; it is
        # checked through the HBase export instead.
        expected.pop("bank_customer_summary", None)
    elif a.engine == "spark":
        d = os.path.join(PROJECT, "results", "spark_outputs_" + a.dataset)
        got = {}
        for p in glob.glob(os.path.join(d, "*.csv")):
            got[os.path.basename(p)[:-4]] = load_csv(p)
    else:
        ap.error("give --engine or --hbase-csv")

    for name in sorted(expected):
        ok, msg = compare(name, expected[name], got.get(name))
        ok_all = ok_all and ok
        lines.append("%s %-26s %s" % ("PASS" if ok else "FAIL", name, msg))
    lines.append("RESULT: " + ("ALL OUTPUTS MATCH" if ok_all else "MISMATCHES FOUND"))
    report = os.path.join(PROJECT, "results",
                          "verification_%s_%s.txt" % (a.engine, a.dataset))
    with open(report, "w") as fh:
        fh.write("Engine: %s   Dataset: %s\n" % (a.engine, a.dataset))
        fh.write("\n".join(lines) + "\n")
    print("\n".join(lines))
    print("Report: " + report)
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
