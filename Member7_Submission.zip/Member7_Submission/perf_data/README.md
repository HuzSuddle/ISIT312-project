# Timing datasets (synthetic)

These datasets exist only to make the timing measurements meaningful. With 2,000 rows, Hive's fixed start-up and job-launch overhead hides any effect of data volume.

| Dataset | Customers | Accounts | Transactions | How it was made |
|---|---|---|---|---|
| small (team default) | 200 | 300 | 2,000 | Member 5 default, already in `bank_analytics` |
| large | 2,000 | 3,000 | 20,000 | `generate_synthetic_data.py --size large` |
| xlarge | 20,000 | 30,000 | 200,000 | `generate_synthetic_data.py --customers 20000 --accounts 30000 --transactions 200000` |

The same steps were used for both datasets:

1. Generated with Member 5's generator v1.0, seed 312 (see `manifest_member5_generator.json` for SHA-256 hashes).
2. Validated with Member 5's `validate_data.py`, which reported 68 passed and 0 failed for each (`member5_validation.txt`).
3. Cleaned with Member 6's unchanged `02_clean_curate.py`, which accepted every row and rejected none (event_ts converted to `YYYY-MM-DD HH:MM:SS`).

The files are in the same format as Member 6's cleaned and curated files, so they can be loaded into separate Hive databases with `code/06_load_perf_datasets.sh`.

Even 200,000 transactions are tiny compared with the bank. The bank reports a database of about 16 TB, more than 1.5 million customers and more than 1.6 million accounts, growing about 4 GB a week. These datasets therefore show how run time changes with volume on the lab VM. They do not predict bank run times.
