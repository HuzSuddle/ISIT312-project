# Member 7 – Analytical Jobs, Reporting Use Cases and Measurements

ISIT312 banking data lake prototype. All data is synthetic (Member 5); the jobs run on Member 6's Hive tables.

## What is in this folder

| Work-package deliverable | Where |
|---|---|
| Report section (05_sample_jobs_and_evaluation.docx) | `01_report_and_slides/` |
| Presentation slides (query outputs + measured results) | `01_report_and_slides/member7_query_outputs_and_measurements.pptx` |
| Job scripts | `code/04a_job1_daily_channel.hql`, `04b_job2_customer_summary.hql`, `04c_job3_exception_review.hql`, `code/spark/04_sample_jobs_spark.py` |
| Timing, verification and export scripts | `code/05_run_jobs_timed.sh`, `07_verify_outputs.py`, `08_export_hbase_feed.sh`, `09_summarise_timings.py` |
| Job outputs | `results/vm_run/hive_outputs_*` (raw Hive output and logs from every run), `results/vm_run/spark_outputs_small/` (CSV). Expected outputs used for checking are in `results/expected_*/` |
| Verification reports | `results/vm_run/verification_*.txt`, all four reporting ALL OUTPUTS MATCH |
| Timing log | `results/vm_run/timing_log.csv` (all 33 runs) and `results/vm_run/timing_summary.csv` |
| HBase feed for Member 9 | `results/customer_summary_for_hbase.csv` (as exported from Hive on the VM: `results/vm_run/customer_summary_for_hbase_vm.csv`) + `docs/hbase_handoff_member9.md` |
| Screenshots | `evidence/screenshots_full/` (original VM screenshots), `evidence/figures/` (crops used in the report) |
| Timing datasets (20k / 200k transactions) | `perf_data/` |
| How to re-run everything on the VM | `docs/vm_runbook.md` |

## Results in one paragraph

All three jobs ran on the team BigdataVM: 2 vCPUs, 7,983 MB RAM, Hadoop 2.7.3, Hive 2.1.1 on MapReduce, and Spark 3.0.3 in local[2] mode. Every output matched the expected results. That held for Hive on 2,000, 20,000 and 200,000 transactions, for Spark on 2,000 transactions, and for the 200-row HBase export. Hive took about 90–305 seconds per job at every data size, so on this VM its run time reflects MapReduce start-up rather than data volume. Spark ran the same SQL in 1.4–2.2 seconds per job, plus a one-off session start-up of 3.3 seconds. None of these timings is comparable with the bank's ~1-hour report on a ~16 TB Oracle database.

## Note on the VM files

Everything in `results/vm_run/` was copied directly from `~/member7_jobs/results` on the team BigdataVM after the runs on 23 November 2026. Spark's one-off session start-up was 3.3 seconds and is recorded in the `notes` column of `timing_log.csv`.
